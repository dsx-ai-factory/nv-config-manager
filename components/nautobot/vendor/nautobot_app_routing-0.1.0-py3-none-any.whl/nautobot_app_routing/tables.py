# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Tables for the routing plugin."""

import django_tables2 as tables
from nautobot.apps.tables import BaseTable, ButtonsColumn, TagColumn, ToggleColumn
from nautobot.extras.tables import StatusTableMixin

from nautobot_app_routing import models


class CheckmarkColumn(tables.BooleanColumn):
    """Render true as a checkmark and false as blank."""

    def render(self, value):
        return "✔" if value else ""


class AutonomousSystemTable(StatusTableMixin, BaseTable):
    """Table for AutonomousSystem list view."""

    pk = ToggleColumn()
    asn = tables.Column(linkify=True)
    provider = tables.Column(linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.AutonomousSystem)

    class Meta(BaseTable.Meta):
        model = models.AutonomousSystem
        fields = ("pk", "asn", "provider", "status", "description", "tags")


class BGPRoutingInstanceTable(StatusTableMixin, BaseTable):
    """Table for BGPRoutingInstance list view."""

    pk = ToggleColumn()
    device = tables.Column(linkify=True)
    autonomous_system = tables.Column(linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.BGPRoutingInstance)

    class Meta(BaseTable.Meta):
        model = models.BGPRoutingInstance
        fields = ("pk", "device", "autonomous_system", "router_id", "status", "description", "tags")


class PeerGroupTemplateTable(BaseTable):
    """Table for PeerGroupTemplate list view."""

    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    enabled = CheckmarkColumn()
    tags = TagColumn()
    actions = ButtonsColumn(models.PeerGroupTemplate)

    class Meta(BaseTable.Meta):
        model = models.PeerGroupTemplate
        fields = ("pk", "name", "autonomous_system", "role", "enabled", "description", "tags")


class PeerGroupTable(BaseTable):
    """Table for PeerGroup list view."""

    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    routing_instance = tables.Column(linkify=True)
    vrf = tables.Column(linkify=True)
    enabled = CheckmarkColumn()
    tags = TagColumn()
    actions = ButtonsColumn(models.PeerGroup)

    class Meta(BaseTable.Meta):
        model = models.PeerGroup
        fields = ("pk", "name", "routing_instance", "vrf", "enabled", "description", "tags")


class PeeringTable(StatusTableMixin, BaseTable):
    """Table for Peering list view."""

    pk = ToggleColumn()
    endpoints = tables.Column(empty_values=(), verbose_name="Endpoints")
    tags = TagColumn()
    actions = ButtonsColumn(models.Peering)

    def render_endpoints(self, record):
        return ", ".join(str(endpoint) for endpoint in record.endpoints.all())

    class Meta(BaseTable.Meta):
        model = models.Peering
        fields = ("pk", "endpoints", "status", "tags")


class PeerEndpointTable(BaseTable):
    """Table for PeerEndpoint list and peering detail views."""

    pk = ToggleColumn()
    peering = tables.Column(linkify=True)
    routing_instance = tables.Column(linkify=True)
    peer_group = tables.Column(linkify=True)
    source_ip = tables.Column(linkify=True)
    source_interface = tables.Column(linkify=True)
    enabled = CheckmarkColumn()
    tags = TagColumn()
    actions = ButtonsColumn(models.PeerEndpoint)

    class Meta(BaseTable.Meta):
        model = models.PeerEndpoint
        fields = (
            "pk",
            "peering",
            "routing_instance",
            "peer_group",
            "autonomous_system",
            "source_ip",
            "source_interface",
            "enabled",
            "tags",
        )


class AddressFamilyTable(BaseTable):
    """Table for AddressFamily list view."""

    pk = ToggleColumn()
    routing_instance = tables.Column(linkify=True)
    import_policy = tables.Column(linkify=True)
    export_policy = tables.Column(linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.AddressFamily)

    class Meta(BaseTable.Meta):
        model = models.AddressFamily
        fields = ("pk", "routing_instance", "afi_safi", "import_policy", "export_policy", "tags")


class RoutingPolicyTable(BaseTable):
    """Table for RoutingPolicy list view."""

    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.RoutingPolicy)

    class Meta(BaseTable.Meta):
        model = models.RoutingPolicy
        fields = ("pk", "name", "default_action", "description", "tags")


class RoutingPolicyTermTable(BaseTable):
    """Table for RoutingPolicyTerm list view."""

    pk = ToggleColumn()
    policy = tables.Column(linkify=True)
    name = tables.Column(linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.RoutingPolicyTerm)

    class Meta(BaseTable.Meta):
        model = models.RoutingPolicyTerm
        fields = ("pk", "policy", "sequence", "name", "from_policy", "then_action", "tags")


class PrefixListTable(BaseTable):
    """Table for PrefixList list view."""

    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    address_family = tables.Column()
    tags = TagColumn()
    actions = ButtonsColumn(models.PrefixList)

    class Meta(BaseTable.Meta):
        model = models.PrefixList
        fields = ("pk", "name", "address_family", "description", "tags")


class PrefixListEntryTable(BaseTable):
    """Table for PrefixListEntry list view."""

    pk = ToggleColumn()
    prefix_list = tables.Column(linkify=True)
    prefix = tables.Column(linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.PrefixListEntry)

    class Meta(BaseTable.Meta):
        model = models.PrefixListEntry
        fields = ("pk", "prefix_list", "prefix", "match", "tags")


class CommunityDimensionTable(BaseTable):
    """Table for CommunityDimension list view."""

    pk = ToggleColumn()
    code = tables.Column(linkify=True)
    parent = tables.Column(linkify=True)
    location = tables.Column(linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.CommunityDimension)

    class Meta(BaseTable.Meta):
        model = models.CommunityDimension
        fields = ("pk", "kind", "code", "community_id", "parent", "location", "tags")


class ISISRoutingInstanceTable(BaseTable):
    """Table for ISISRoutingInstance list view."""

    pk = ToggleColumn()
    device = tables.Column(linkify=True)
    net = tables.Column(linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.ISISRoutingInstance)

    class Meta(BaseTable.Meta):
        model = models.ISISRoutingInstance
        fields = ("pk", "device", "net", "protocol_authentication", "tags")


class ISISInterfaceTable(BaseTable):
    """Table for ISISInterface list view."""

    pk = ToggleColumn()
    interface = tables.Column(linkify=True)
    device = tables.Column(accessor="interface__device", linkify=True)
    passive = CheckmarkColumn()
    tags = TagColumn()
    actions = ButtonsColumn(models.ISISInterface)

    class Meta(BaseTable.Meta):
        model = models.ISISInterface
        fields = ("pk", "device", "interface", "metric", "level", "passive", "tags")


class MPLSInterfaceTable(BaseTable):
    """Table for MPLSInterface list view."""

    pk = ToggleColumn()
    interface = tables.Column(linkify=True)
    device = tables.Column(accessor="interface__device", linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.MPLSInterface)

    class Meta(BaseTable.Meta):
        model = models.MPLSInterface
        fields = ("pk", "device", "interface", "srlg", "admin_groups", "tags")


class RSVPInterfaceTable(BaseTable):
    """Table for RSVPInterface list view."""

    pk = ToggleColumn()
    interface = tables.Column(linkify=True)
    device = tables.Column(accessor="interface__device", linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.RSVPInterface)

    class Meta(BaseTable.Meta):
        model = models.RSVPInterface
        fields = ("pk", "device", "interface", "subscription_percent", "link_protection", "tags")


class MACsecAssociationTable(BaseTable):
    """Table for MACsecAssociation list view."""

    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    include_sci = CheckmarkColumn()
    tags = TagColumn()
    actions = ButtonsColumn(models.MACsecAssociation)

    class Meta(BaseTable.Meta):
        model = models.MACsecAssociation
        fields = ("pk", "name", "mode", "include_sci", "secret", "tags")


class TransportClassTable(StatusTableMixin, BaseTable):
    """Table for TransportClass list view."""

    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.TransportClass)

    class Meta(BaseTable.Meta):
        model = models.TransportClass
        fields = ("pk", "name", "lsp_class", "color", "status", "tags")


class MPLSTemplateTable(BaseTable):
    """Table for MPLSTemplate list view."""

    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    transport_class = tables.Column(linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.MPLSTemplate)

    class Meta(BaseTable.Meta):
        model = models.MPLSTemplate
        fields = ("pk", "name", "transport_class", "description", "tags")


class LabelSwitchedPathTable(StatusTableMixin, BaseTable):
    """Table for LabelSwitchedPath list view."""

    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    device = tables.Column(linkify=True)
    template = tables.Column(linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.LabelSwitchedPath)

    class Meta(BaseTable.Meta):
        model = models.LabelSwitchedPath
        fields = ("pk", "name", "device", "template", "to_address", "status", "tags")


class EVPNPWServiceTable(StatusTableMixin, BaseTable):
    """Table for EVPNPWService list view."""

    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    interface = tables.Column(linkify=True)
    remote_pe = tables.Column(linkify=True)
    tags = TagColumn()
    actions = ButtonsColumn(models.EVPNPWService)

    class Meta(BaseTable.Meta):
        model = models.EVPNPWService
        fields = (
            "pk",
            "name",
            "local_service_id",
            "remote_service_id",
            "interface",
            "remote_pe",
            "remote_pe_address",
            "route_distinguisher",
            "status",
            "tags",
        )
