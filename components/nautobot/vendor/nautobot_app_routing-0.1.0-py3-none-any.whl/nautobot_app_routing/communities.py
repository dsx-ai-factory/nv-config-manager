# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Derived location community helpers."""

from nautobot_app_routing.choices import CommunityKindChoices

NVIDIA_ASN = 398037
LOC_COMMUNITY_TYPE = 10


def loc_community_for_device(device):
    """Return ASN:10:site_id for a device, or None if no site dimension maps."""
    from nautobot_app_routing.models import CommunityDimension

    location = getattr(device, "location", None)
    if location is None:
        return None
    site = (
        CommunityDimension.objects.filter(kind=CommunityKindChoices.SITE, location=location).first()
        or CommunityDimension.objects.filter(kind=CommunityKindChoices.SITE, code=location.name).first()
    )
    if site is None:
        return None
    return f"{NVIDIA_ASN}:{LOC_COMMUNITY_TYPE}:{site.community_id}"
