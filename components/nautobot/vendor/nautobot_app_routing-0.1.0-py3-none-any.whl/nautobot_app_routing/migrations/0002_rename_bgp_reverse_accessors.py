# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Avoid reverse-name clashes with nautobot-bgp-models on shared core models."""

import django.db.models.deletion
import nautobot.core.models.fields
import nautobot.extras.models.roles
import nautobot.extras.models.statuses
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("nautobot_app_routing", "0001_initial"),
    ]

    operations = [
        migrations.AlterField(
            model_name="autonomoussystem",
            name="provider",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="routing_autonomous_systems",
                to="circuits.provider",
            ),
        ),
        migrations.AlterField(
            model_name="autonomoussystem",
            name="status",
            field=nautobot.extras.models.statuses.StatusField(
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="routing_autonomous_systems",
                to="extras.status",
            ),
        ),
        migrations.AlterField(
            model_name="autonomoussystem",
            name="tags",
            field=nautobot.core.models.fields.TagsField(
                related_name="routing_autonomous_systems",
                through="extras.TaggedItem",
                to="extras.Tag",
            ),
        ),
        migrations.AlterField(
            model_name="bgproutinginstance",
            name="device",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.PROTECT,
                related_name="routing_bgp_routing_instances",
                to="dcim.device",
            ),
        ),
        migrations.AlterField(
            model_name="bgproutinginstance",
            name="router_id",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="routing_bgp_routing_instances",
                to="ipam.ipaddress",
            ),
        ),
        migrations.AlterField(
            model_name="bgproutinginstance",
            name="status",
            field=nautobot.extras.models.statuses.StatusField(
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="routing_bgp_routing_instances",
                to="extras.status",
            ),
        ),
        migrations.AlterField(
            model_name="bgproutinginstance",
            name="tags",
            field=nautobot.core.models.fields.TagsField(
                related_name="routing_bgp_routing_instances",
                through="extras.TaggedItem",
                to="extras.Tag",
            ),
        ),
        migrations.AlterField(
            model_name="peergrouptemplate",
            name="role",
            field=nautobot.extras.models.roles.RoleField(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="routing_bgp_peer_group_templates",
                to="extras.role",
            ),
        ),
        migrations.AlterField(
            model_name="peergrouptemplate",
            name="tags",
            field=nautobot.core.models.fields.TagsField(
                related_name="routing_bgp_peer_group_templates",
                through="extras.TaggedItem",
                to="extras.Tag",
            ),
        ),
        migrations.AlterField(
            model_name="peergroup",
            name="role",
            field=nautobot.extras.models.roles.RoleField(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="routing_bgp_peer_groups",
                to="extras.role",
            ),
        ),
        migrations.AlterField(
            model_name="peergroup",
            name="tags",
            field=nautobot.core.models.fields.TagsField(
                related_name="routing_bgp_peer_groups",
                through="extras.TaggedItem",
                to="extras.Tag",
            ),
        ),
        migrations.AlterField(
            model_name="peering",
            name="status",
            field=nautobot.extras.models.statuses.StatusField(
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="routing_bgp_peerings",
                to="extras.status",
            ),
        ),
        migrations.AlterField(
            model_name="peerendpoint",
            name="role",
            field=nautobot.extras.models.roles.RoleField(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="routing_bgp_peer_endpoints",
                to="extras.role",
            ),
        ),
        migrations.AlterField(
            model_name="peerendpoint",
            name="tags",
            field=nautobot.core.models.fields.TagsField(
                related_name="routing_bgp_peer_endpoints",
                through="extras.TaggedItem",
                to="extras.Tag",
            ),
        ),
        migrations.AlterField(
            model_name="addressfamily",
            name="tags",
            field=nautobot.core.models.fields.TagsField(
                related_name="routing_bgp_address_families",
                through="extras.TaggedItem",
                to="extras.Tag",
            ),
        ),
    ]
