# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Add Peering tags and correct routing UI model labels."""

import nautobot.core.models.fields
from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [
        ("extras", "0125_jobresult_date_started"),
        ("nautobot_app_routing", "0002_rename_bgp_reverse_accessors"),
    ]

    operations = [
        migrations.AlterModelOptions(
            name="addressfamily",
            options={"verbose_name": "BGP Address Family", "verbose_name_plural": "BGP Address Families"},
        ),
        migrations.AlterModelOptions(
            name="autonomoussystem",
            options={
                "ordering": ["asn"],
                "verbose_name": "Autonomous System",
                "verbose_name_plural": "Autonomous Systems",
            },
        ),
        migrations.AlterModelOptions(
            name="bgproutinginstance",
            options={"verbose_name": "BGP Routing Instance", "verbose_name_plural": "BGP Routing Instances"},
        ),
        migrations.AlterModelOptions(
            name="labelswitchedpath",
            options={"ordering": ["device__name", "name"], "verbose_name": "LSP", "verbose_name_plural": "LSPs"},
        ),
        migrations.AlterModelOptions(
            name="mplstemplate",
            options={"ordering": ["name"], "verbose_name": "LSP Template", "verbose_name_plural": "LSP Templates"},
        ),
        migrations.AlterModelOptions(
            name="peerendpoint",
            options={"verbose_name": "BGP Peer Endpoint", "verbose_name_plural": "BGP Peer Endpoints"},
        ),
        migrations.AlterModelOptions(
            name="peergroup",
            options={"ordering": ["name"], "verbose_name": "BGP Peer Group", "verbose_name_plural": "BGP Peer Groups"},
        ),
        migrations.AlterModelOptions(
            name="peergrouptemplate",
            options={"verbose_name": "BGP Peer Group Template", "verbose_name_plural": "BGP Peer Group Templates"},
        ),
        migrations.AlterModelOptions(
            name="peering",
            options={"verbose_name": "BGP Peering", "verbose_name_plural": "BGP Peerings"},
        ),
        migrations.AddField(
            model_name="peering",
            name="tags",
            field=nautobot.core.models.fields.TagsField(through="extras.TaggedItem", to="extras.Tag"),
        ),
    ]
