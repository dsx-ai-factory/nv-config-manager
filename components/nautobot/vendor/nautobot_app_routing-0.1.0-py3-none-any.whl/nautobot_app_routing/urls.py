# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""URL patterns for the routing plugin."""

from nautobot.apps.urls import NautobotUIViewSetRouter

from nautobot_app_routing import views

app_name = "nautobot_app_routing"

router = NautobotUIViewSetRouter()

router.register("isis-routing-instances", views.ISISRoutingInstanceUIViewSet)
router.register("isis-interfaces", views.ISISInterfaceUIViewSet)
router.register("mpls-interfaces", views.MPLSInterfaceUIViewSet)
router.register("rsvp-interfaces", views.RSVPInterfaceUIViewSet)
router.register("transport-classes", views.TransportClassUIViewSet)
router.register("mpls-templates", views.MPLSTemplateUIViewSet)
router.register("lsps", views.LabelSwitchedPathUIViewSet)
router.register("evpn-vpws", views.EVPNPWServiceUIViewSet)
router.register("macsec-associations", views.MACsecAssociationUIViewSet)
router.register("autonomous-systems", views.AutonomousSystemUIViewSet)
router.register("bgp-routing-instances", views.BGPRoutingInstanceUIViewSet)
router.register("peer-group-templates", views.PeerGroupTemplateUIViewSet)
router.register("peer-groups", views.PeerGroupUIViewSet)
router.register("peerings", views.PeeringUIViewSet)
router.register("peer-endpoints", views.PeerEndpointUIViewSet)
router.register("address-families", views.AddressFamilyUIViewSet)
router.register("routing-policies", views.RoutingPolicyUIViewSet)
router.register("routing-policy-terms", views.RoutingPolicyTermUIViewSet)
router.register("prefix-lists", views.PrefixListUIViewSet)
router.register("prefix-list-entries", views.PrefixListEntryUIViewSet)
router.register("communities", views.CommunityDimensionUIViewSet)

urlpatterns = router.urls
