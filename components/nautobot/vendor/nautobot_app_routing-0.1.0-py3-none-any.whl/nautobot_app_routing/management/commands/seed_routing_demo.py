# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Seed AMS0A-inspired routing demo data.

Link topology lives in core: physical member interfaces are cabled, and long-haul
and peering spans terminate on circuits. This app only seeds protocol intent.
"""

from django.contrib.contenttypes.models import ContentType
from django.core.management.base import BaseCommand
from nautobot.circuits.models import Circuit, CircuitTermination, CircuitType, Provider
from nautobot.dcim.models import (
    Cable,
    Device,
    DeviceType,
    Interface,
    Location,
    LocationType,
    Manufacturer,
    Platform,
)
from nautobot.extras.models import Role, Status
from nautobot.ipam.models import VRF, IPAddress, Namespace, Prefix

from nautobot_app_routing import choices, models
from nautobot_app_routing.communities import loc_community_for_device

FLUSH_ORDER = (
    models.EVPNPWService,
    models.LabelSwitchedPath,
    models.MPLSTemplate,
    models.TransportClass,
    models.AddressFamily,
    models.PeerEndpoint,
    models.Peering,
    models.PeerGroup,
    models.PeerGroupTemplate,
    models.BGPRoutingInstance,
    models.AutonomousSystem,
    models.RSVPInterface,
    models.MPLSInterface,
    models.ISISInterface,
    models.ISISRoutingInstance,
    models.MACsecAssociation,
    models.RoutingPolicyTerm,
    models.RoutingPolicy,
    models.PrefixListEntry,
    models.PrefixList,
)


class Command(BaseCommand):
    """Populate routing demo data from render_context examples."""

    help = "Populate routing demo data for backbone link mockups"

    def add_arguments(self, parser):
        parser.add_argument(
            "--flush",
            action="store_true",
            help="Delete existing routing plugin data before seeding",
        )

    def handle(self, *args, **options):
        if options["flush"]:
            self.stdout.write("Flushing routing plugin data...")
            self._flush()

        self.stdout.write("Seeding routing demo data...")
        self._seed()
        self.stdout.write(self.style.SUCCESS("Routing demo data ready"))

    def _flush(self):
        for model in FLUSH_ORDER:
            model.objects.all().delete()
        models.CommunityDimension.objects.update(parent=None)
        models.CommunityDimension.objects.all().delete()

    def _seed(self):
        locations = self._seed_locations()
        self._seed_communities(locations)
        devices = self._seed_devices(locations)
        interfaces = self._seed_interfaces(devices)
        circuits = self._seed_circuits(locations)
        self._seed_cabling(interfaces, circuits)
        addresses = self._seed_addressing(interfaces)
        self._seed_isis(devices, interfaces)
        transport = self._seed_mpls_rsvp(devices, interfaces)
        self._seed_macsec(interfaces)
        policies = self._seed_policies()
        self._seed_bgp(devices, addresses, policies)
        self._seed_vpws(devices, interfaces, circuits, transport)
        self._report(devices["ams_bbr01"])

    def _status_for(self, model_class, name="Active"):
        content_type = ContentType.objects.get_for_model(model_class)
        status = Status.objects.filter(name=name).first()
        if status is None:
            status = Status.objects.create(name=name)
        if not status.content_types.filter(pk=content_type.pk).exists():
            status.content_types.add(content_type)
        return status

    def _seed_locations(self):
        location_type, _ = LocationType.objects.get_or_create(name="PoP")
        location_type.content_types.add(ContentType.objects.get_for_model(Device))
        location_type.content_types.add(ContentType.objects.get_for_model(CircuitTermination))
        status = Status.objects.get_for_model(Location).first()

        locations = {}
        for name in ("AMS0A", "IAD0A", "EWR0A", "LHR0A2"):
            locations[name], _ = Location.objects.get_or_create(
                name=name,
                defaults={"location_type": location_type, "status": status},
            )
        return locations

    def _dim(self, kind, code, community_id, parent=None, location=None):
        obj, _ = models.CommunityDimension.objects.get_or_create(
            kind=kind,
            code=code,
            defaults={"community_id": community_id, "parent": parent, "location": location},
        )
        if location and obj.location_id != location.pk:
            obj.location = location
            obj.save()
        return obj

    def _seed_communities(self, locations):
        kinds = choices.CommunityKindChoices
        emeia = self._dim(kinds.CONTINENT, "EMEIA", "4...")
        na = self._dim(kinds.CONTINENT, "NA", "1...")
        asia = self._dim(kinds.CONTINENT, "ASIA", "6...")

        westeu = self._dim(kinds.REGION, "WESTEU", "41..", parent=emeia)
        useast = self._dim(kinds.REGION, "USEAST", "17..", parent=na)
        uswest = self._dim(kinds.REGION, "USWEST", "11..", parent=na)
        self._dim(kinds.REGION, "APAC", "61..", parent=asia)

        metro_ams = self._dim(kinds.METRO, "AMS", "412.", parent=westeu)
        metro_iad = self._dim(kinds.METRO, "IAD", "172.", parent=useast)
        metro_nyc = self._dim(kinds.METRO, "NYC", "171.", parent=useast)
        metro_lhr = self._dim(kinds.METRO, "LHR", "411.", parent=westeu)
        self._dim(kinds.METRO, "PDX", "113.", parent=uswest)

        self._dim(kinds.SITE, "AMS0A", "4121", parent=metro_ams, location=locations["AMS0A"])
        self._dim(kinds.SITE, "IAD0A", "1721", parent=metro_iad, location=locations["IAD0A"])
        self._dim(kinds.SITE, "EWR0A", "1713", parent=metro_nyc, location=locations["EWR0A"])
        self._dim(kinds.SITE, "LHR0A2", "4111", parent=metro_lhr, location=locations["LHR0A2"])

        self._dim(kinds.SCOPE, "WORLD", "1001")
        self._dim(kinds.SCOPE, "METRO", "1004")
        self._dim(kinds.TYPE, "TRANSIT", "1010")
        self._dim(kinds.TYPE, "IXP", "1012")
        cloud = self._dim(kinds.TYPE, "CLOUD", "1020")
        self._dim(kinds.CLOUD_PROVIDER, "GCP", "1021", parent=cloud)
        self._dim(kinds.CLOUD_PROVIDER, "AWS", "1020", parent=cloud)

    def _seed_devices(self, locations):
        manufacturer, _ = Manufacturer.objects.get_or_create(name="Juniper")
        device_type, _ = DeviceType.objects.get_or_create(manufacturer=manufacturer, model="PTX10008")
        platform, _ = Platform.objects.get_or_create(name="junos")
        status = Status.objects.get_for_model(Device).first()
        role, _ = Role.objects.get_or_create(name="Backbone Router")
        role.content_types.add(ContentType.objects.get_for_model(Device))

        def device(name, location):
            obj, _ = Device.objects.get_or_create(
                name=name,
                defaults={
                    "device_type": device_type,
                    "platform": platform,
                    "location": location,
                    "status": status,
                    "role": role,
                },
            )
            return obj

        return {
            "ams_bbr01": device("AMS0A-BBR-01", locations["AMS0A"]),
            "ams_bbr02": device("AMS0A-BBR-02", locations["AMS0A"]),
            "iad_bbr01": device("IAD0A-BBR-01", locations["IAD0A"]),
            "ewr_bbr01": device("EWR0A-BBR-01", locations["EWR0A"]),
            "lhr_bbr01": device("LHR0A2-BBR-01", locations["LHR0A2"]),
        }

    def _interface_roles(self):
        """Seed the workbook profile matrix as core Interface roles."""
        content_type = ContentType.objects.get_for_model(Interface)
        roles = {}
        for value, label in choices.InterfaceProfileChoices.CHOICES:
            role, _ = Role.objects.get_or_create(name=label)
            role.content_types.add(content_type)
            roles[value] = role
        return roles

    def _seed_interfaces(self, devices):
        profiles = self._interface_roles()
        status = Status.objects.get_for_model(Interface).first()

        def iface(device, name, if_type="100gbase-x-qsfp28", profile=None, mtu=9192, lag=None):
            obj, _ = Interface.objects.get_or_create(
                device=device,
                name=name,
                defaults={
                    "type": if_type,
                    "status": status,
                    "mtu": mtu,
                    "role": profiles.get(profile),
                    "lag": lag,
                },
            )
            return obj

        intra = choices.InterfaceProfileChoices.BACKBONE_INTRA_SITE
        long_haul = choices.InterfaceProfileChoices.BACKBONE_LONG_HAUL
        peer = choices.InterfaceProfileChoices.ROUTED_PEER
        pseudowire = choices.InterfaceProfileChoices.PSEUDOWIRE

        ae100_a = iface(devices["ams_bbr01"], "ae100", "lag", intra)
        ae100_z = iface(devices["ams_bbr02"], "ae100", "lag", intra)
        ae1200_a = iface(devices["ams_bbr01"], "ae1200", "lag", long_haul)
        ae1203_z = iface(devices["iad_bbr01"], "ae1203", "lag", long_haul)

        return {
            "ae100_a": ae100_a,
            "ae100_z": ae100_z,
            "ae1200_a": ae1200_a,
            "ae1203_z": ae1203_z,
            "ae100_mem_a": iface(devices["ams_bbr01"], "et-0/0/35:1", "400gbase-x-qsfpdd", lag=ae100_a),
            "ae100_mem_z": iface(devices["ams_bbr02"], "et-0/0/35:1", "400gbase-x-qsfpdd", lag=ae100_z),
            "ae1200_mem_a": iface(devices["ams_bbr01"], "et-0/0/34:0", "400gbase-x-qsfpdd", lag=ae1200_a),
            "ae1203_mem_z": iface(devices["iad_bbr01"], "et-0/0/34:0", "400gbase-x-qsfpdd", lag=ae1203_z),
            "transit": iface(devices["ams_bbr01"], "et-0/0/0", profile=peer),
            "ix": iface(devices["ams_bbr01"], "et-0/0/1", profile=peer),
            "pw_a": iface(devices["ams_bbr01"], "et-0/0/5", profile=pseudowire),
            "pw_z": iface(devices["lhr_bbr01"], "et-0/0/5", profile=pseudowire),
            "pw_a2": iface(devices["ams_bbr01"], "et-0/0/6", profile=pseudowire),
        }

    def _seed_circuits(self, locations):
        exainfra, _ = Provider.objects.get_or_create(name="ExaInfra")
        arelion, _ = Provider.objects.get_or_create(name="Arelion")
        equinix, _ = Provider.objects.get_or_create(name="EQUINIX")
        wave, _ = CircuitType.objects.get_or_create(name="Wave")
        transit_type, _ = CircuitType.objects.get_or_create(name="Transit")
        ix_type, _ = CircuitType.objects.get_or_create(name="Internet Exchange")
        status = Status.objects.get_for_model(Circuit).first()

        def circuit(cid, provider, circuit_type, sides):
            obj, _ = Circuit.objects.get_or_create(
                cid=cid,
                defaults={"provider": provider, "circuit_type": circuit_type, "status": status},
            )
            for side, location in sides.items():
                CircuitTermination.objects.get_or_create(
                    circuit=obj,
                    term_side=side,
                    defaults={"location": location},
                )
            return obj

        return {
            "wave": circuit(
                "NVBV1/WAVE/169213",
                exainfra,
                wave,
                {"A": locations["AMS0A"], "Z": locations["IAD0A"]},
            ),
            "transit": circuit("ARELION-AMS0A-01", arelion, transit_type, {"A": locations["AMS0A"]}),
            "ix": circuit("EQUINIX-AMS-IX-01", equinix, ix_type, {"A": locations["AMS0A"]}),
            "providers": {"arelion": arelion, "equinix": equinix},
        }

    def _seed_cabling(self, interfaces, circuits):
        """Pair terminations with core Cables; long-haul and peering ride circuits."""
        status = Status.objects.get_for_model(Cable).first()

        def connect(termination_a, termination_b):
            if termination_a.cable_id or termination_b.cable_id:
                return
            Cable.objects.create(
                termination_a=termination_a,
                termination_b=termination_b,
                status=status,
                type="smf",
            )

        def circuit_side(circuit, side):
            return CircuitTermination.objects.get(circuit=circuit, term_side=side)

        connect(interfaces["ae100_mem_a"], interfaces["ae100_mem_z"])
        connect(interfaces["ae1200_mem_a"], circuit_side(circuits["wave"], "A"))
        connect(interfaces["ae1203_mem_z"], circuit_side(circuits["wave"], "Z"))
        connect(interfaces["transit"], circuit_side(circuits["transit"], "A"))
        connect(interfaces["ix"], circuit_side(circuits["ix"], "A"))

    def _seed_addressing(self, interfaces):
        namespace, _ = Namespace.objects.get_or_create(name="Global")
        prefix_status = Status.objects.get_for_model(Prefix).first()
        ip_status = Status.objects.get_for_model(IPAddress).first()

        def address(cidr, host, mask, interface=None):
            prefix, _ = Prefix.objects.get_or_create(
                prefix=cidr,
                namespace=namespace,
                defaults={"status": prefix_status},
            )
            ip, _ = IPAddress.objects.get_or_create(
                host=host,
                mask_length=mask,
                defaults={"status": ip_status, "parent": prefix},
            )
            if interface:
                ip.interfaces.add(interface)
            return ip

        address("10.16.11.0/24", "10.16.11.76", 31, interfaces["ae100_a"])
        address("10.16.11.0/24", "10.16.11.78", 31, interfaces["ae1200_a"])
        return {
            "transit_local": address("62.115.41.206/31", "62.115.41.207", 31, interfaces["transit"]),
            "transit_peer": address("62.115.41.206/31", "62.115.41.206", 31),
            "ix_local": address("185.1.112.0/24", "185.1.112.47", 24, interfaces["ix"]),
            "ix_peer": address("185.1.112.0/24", "185.1.112.251", 24),
        }

    def _seed_isis(self, devices, interfaces):
        models.ISISRoutingInstance.objects.get_or_create(
            device=devices["ams_bbr01"],
            defaults={"net": "49.0039.8037.0000.0100.1602.4024.00"},
        )
        models.ISISRoutingInstance.objects.get_or_create(
            device=devices["ams_bbr02"],
            defaults={"net": "49.0039.8037.0000.0100.1602.4025.00"},
        )
        models.ISISRoutingInstance.objects.get_or_create(
            device=devices["iad_bbr01"],
            defaults={"net": "49.0039.8037.0000.0100.1721.4001.00"},
        )

        for key, metric in (("ae100_a", 10), ("ae100_z", 10), ("ae1200_a", 890), ("ae1203_z", 890)):
            models.ISISInterface.objects.get_or_create(
                interface=interfaces[key],
                defaults={"metric": metric, "level": choices.ISISLevelChoices.LEVEL_2},
            )

    def _seed_mpls_rsvp(self, devices, interfaces):
        transport, _ = models.TransportClass.objects.get_or_create(
            name="BASE",
            defaults={
                "lsp_class": choices.LSPClassChoices.BASE,
                "status": self._status_for(models.TransportClass),
            },
        )
        hipri, _ = models.TransportClass.objects.get_or_create(
            name="HIPRI",
            defaults={
                "lsp_class": choices.LSPClassChoices.HIPRI,
                "color": 100,
                "status": self._status_for(models.TransportClass),
            },
        )
        template, _ = models.MPLSTemplate.objects.get_or_create(
            name="BBR-BBR-BASE",
            defaults={"transport_class": transport, "description": "Core base LSP template"},
        )
        models.MPLSTemplate.objects.get_or_create(
            name="BBR-BBR-HIPRI-APAC",
            defaults={"transport_class": hipri, "description": "APAC high priority path template"},
        )
        models.LabelSwitchedPath.objects.get_or_create(
            device=devices["ams_bbr01"],
            name="AMS0A-BBR-01-to-IAD0A-BBR-01-BASE",
            defaults={
                "template": template,
                "to_address": "10.16.11.79",
                "status": self._status_for(models.LabelSwitchedPath),
            },
        )

        for key in ("ae1200_a", "ae1203_z"):
            models.MPLSInterface.objects.get_or_create(
                interface=interfaces[key],
                defaults={"srlg": ["AMS-IAD-NORTH"], "admin_groups": ["long-haul"]},
            )
            models.RSVPInterface.objects.get_or_create(
                interface=interfaces[key],
                defaults={
                    "subscription_percent": 100,
                    "link_protection": choices.RSVPProtectionChoices.BYPASS_EXCLUDING_SRLG,
                },
            )
        return hipri

    def _seed_macsec(self, interfaces):
        association, _ = models.MACsecAssociation.objects.get_or_create(
            name="MACSEC-AMS0A-IAD0A",
            defaults={"mode": choices.MACsecModeChoices.PRESHARED, "include_sci": False},
        )
        association.interfaces.add(interfaces["ae1200_mem_a"], interfaces["ae1203_mem_z"])
        return association

    def _seed_policies(self):
        ingress, _ = models.RoutingPolicy.objects.get_or_create(
            name="INGRESS_PEERING_TRANSIT",
            defaults={
                "description": "Transit and IX ingress ACL",
                "default_action": choices.PolicyActionChoices.REJECT,
            },
        )
        gcp_export, _ = models.RoutingPolicy.objects.get_or_create(
            name="GCP_EXPORT",
            defaults={"default_action": choices.PolicyActionChoices.REJECT},
        )
        gcp_import, _ = models.RoutingPolicy.objects.get_or_create(
            name="GCP_IMPORT",
            defaults={"default_action": choices.PolicyActionChoices.REJECT},
        )
        models.RoutingPolicyTerm.objects.get_or_create(
            policy=gcp_export,
            name="TERM_010",
            defaults={
                "sequence": 10,
                "from_policy": "DENY_DEFAULT && SEND_NGC_GCP_PREFIXES && SEND_MED_TEN",
                "then_action": choices.PolicyActionChoices.ACCEPT,
            },
        )
        models.RoutingPolicyTerm.objects.get_or_create(
            policy=gcp_import,
            name="TERM_010",
            defaults={
                "sequence": 10,
                "from_policy": (
                    "DENY_DEFAULT && REMOVE_COMM_ALL && ACCEPT_AS{peer_as}_ROUTE && SET_MED_TEN "
                    "&& SET_LOCALPREF_NGC && SET_SCOPE_WORLD && SET_LOCATION && SET_TYPE_{type_community}"
                ),
                "then_action": choices.PolicyActionChoices.ACCEPT,
            },
        )

        self._prefix_list(
            "DEFAULT_V4",
            choices.AddressFamilyChoices.IPV4,
            [("0.0.0.0/0", choices.PrefixMatchChoices.EXACT)],
        )
        self._prefix_list(
            "DEFAULT_V6",
            choices.AddressFamilyChoices.IPV6,
            [("::/0", choices.PrefixMatchChoices.EXACT)],
        )
        self._prefix_list(
            "NGC_SUPERNETS_V4_ROUTE",
            choices.AddressFamilyChoices.IPV4,
            [
                ("10.0.0.0/8", choices.PrefixMatchChoices.EXACT),
                ("172.16.0.0/12", choices.PrefixMatchChoices.EXACT),
            ],
        )
        return {"ingress": ingress, "gcp_export": gcp_export, "gcp_import": gcp_import}

    def _prefix_list(self, name, family, entries):
        obj, _ = models.PrefixList.objects.get_or_create(
            name=name,
            defaults={"address_family": family},
        )
        for cidr, match in entries:
            models.PrefixListEntry.objects.get_or_create(prefix_list=obj, prefix=cidr, match=match)
        return obj

    def _seed_bgp(self, devices, addresses, policies):
        namespace, _ = Namespace.objects.get_or_create(name="Global")
        vrf, _ = VRF.objects.get_or_create(name="VRF-PUBLIC", defaults={"namespace": namespace})
        as_status = self._status_for(models.AutonomousSystem)
        arelion = Provider.objects.get(name="Arelion")
        equinix = Provider.objects.get(name="EQUINIX")

        nvidia_as, _ = models.AutonomousSystem.objects.get_or_create(
            asn=398037,
            defaults={"description": "NVIDIA backbone AS", "status": as_status},
        )
        arelion_as, _ = models.AutonomousSystem.objects.get_or_create(
            asn=1299,
            defaults={"description": "Arelion", "provider": arelion, "status": as_status},
        )
        ix_as, _ = models.AutonomousSystem.objects.get_or_create(
            asn=24115,
            defaults={"description": "Equinix IX", "provider": equinix, "status": as_status},
        )

        routing_instance, _ = models.BGPRoutingInstance.objects.get_or_create(
            device=devices["ams_bbr01"],
            autonomous_system=nvidia_as,
            defaults={"status": self._status_for(models.BGPRoutingInstance)},
        )
        transit_group, _ = models.PeerGroup.objects.get_or_create(
            name="TRANSIT_ARELION",
            routing_instance=routing_instance,
            defaults={
                "autonomous_system": arelion_as,
                "vrf": vrf,
                "description": "Arelion:AS1299",
            },
        )
        ix_group, _ = models.PeerGroup.objects.get_or_create(
            name="IX-route-collector",
            routing_instance=routing_instance,
            defaults={
                "autonomous_system": ix_as,
                "vrf": vrf,
                "description": "Equinix IX MLPE Route Server",
            },
        )

        models.AddressFamily.objects.get_or_create(
            routing_instance=routing_instance,
            afi_safi=choices.AFISAFIChoices.IPV4_UNICAST,
            defaults={
                "import_policy": policies["gcp_import"],
                "export_policy": policies["gcp_export"],
            },
        )
        models.AddressFamily.objects.get_or_create(
            routing_instance=routing_instance,
            afi_safi=choices.AFISAFIChoices.IPV6_UNICAST,
            defaults={"import_policy": policies["ingress"]},
        )

        self._peering(
            routing_instance,
            transit_group,
            nvidia_as,
            arelion_as,
            addresses["transit_local"],
            addresses["transit_peer"],
        )
        self._peering(
            routing_instance,
            ix_group,
            nvidia_as,
            ix_as,
            addresses["ix_local"],
            addresses["ix_peer"],
        )

    def _peering(self, routing_instance, peer_group, local_as, remote_as, local_ip, remote_ip):
        if models.PeerEndpoint.objects.filter(source_ip=local_ip).exists():
            return
        peering = models.Peering.objects.create(status=self._status_for(models.Peering))
        models.PeerEndpoint.objects.create(
            peering=peering,
            routing_instance=routing_instance,
            peer_group=peer_group,
            autonomous_system=local_as,
            source_ip=local_ip,
        )
        models.PeerEndpoint.objects.create(
            peering=peering,
            autonomous_system=remote_as,
            source_ip=remote_ip,
        )
        return peering

    def _seed_vpws(self, devices, interfaces, circuits, transport):
        models.EVPNPWService.objects.get_or_create(
            name="PW-AMS-LHR-001",
            defaults={
                "local_service_id": 100001,
                "remote_service_id": 100002,
                "interface": interfaces["pw_a"],
                "remote_pe": devices["lhr_bbr01"],
                "remote_pe_address": "10.16.11.201",
                "route_distinguisher": "398037:100001",
                "import_target": "398037:100002",
                "export_target": "398037:100001",
                "transport_class": transport,
                "mtu": 9192,
                "status": self._status_for(models.EVPNPWService),
            },
        )
        models.EVPNPWService.objects.get_or_create(
            name="PW-AMS-IAD-002",
            defaults={
                "local_service_id": 100003,
                "remote_service_id": 100004,
                "interface": interfaces["pw_a2"],
                "remote_pe": devices["iad_bbr01"],
                "remote_pe_address": "10.16.11.79",
                "circuit": circuits["wave"],
                "route_distinguisher": "398037:100003",
                "import_target": "398037:100004",
                "export_target": "398037:100003",
                "transport_class": transport,
                "mtu": 9192,
                "status": self._status_for(models.EVPNPWService),
            },
        )

    def _report(self, device):
        self.stdout.write(f"  loc_community {device}: {loc_community_for_device(device)}")
        self.stdout.write(f"  Cables (core): {Cable.objects.count()}")
        self.stdout.write(f"  IS-IS instances: {models.ISISRoutingInstance.objects.count()}")
        self.stdout.write(f"  IS-IS interfaces: {models.ISISInterface.objects.count()}")
        self.stdout.write(f"  MPLS/RSVP interfaces: {models.MPLSInterface.objects.count()}")
        self.stdout.write(f"  VPWS services: {models.EVPNPWService.objects.count()}")
        self.stdout.write(f"  Community dimensions: {models.CommunityDimension.objects.count()}")
        self.stdout.write(f"  Prefix list entries: {models.PrefixListEntry.objects.count()}")
        self.stdout.write(f"  Policy terms: {models.RoutingPolicyTerm.objects.count()}")
