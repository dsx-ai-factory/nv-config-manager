# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Views for the routing plugin."""

from django_tables2 import RequestConfig
from nautobot.apps.ui import (
    ObjectDetailContent,
    ObjectFieldsPanel,
    ObjectsTablePanel,
    SectionChoices,
)
from nautobot.apps.views import NautobotUIViewSet

from nautobot_app_routing import filters, forms, models, tables


class AutonomousSystemUIViewSet(NautobotUIViewSet):
    """UI ViewSet for AutonomousSystem."""

    bulk_update_form_class = forms.AutonomousSystemBulkEditForm
    filterset_class = filters.AutonomousSystemFilterSet
    filterset_form_class = forms.AutonomousSystemFilterForm
    form_class = forms.AutonomousSystemForm
    queryset = models.AutonomousSystem.objects.select_related("provider")
    table_class = tables.AutonomousSystemTable


class BGPRoutingInstanceUIViewSet(NautobotUIViewSet):
    """UI ViewSet for BGPRoutingInstance."""

    bulk_update_form_class = forms.BGPRoutingInstanceBulkEditForm
    filterset_class = filters.BGPRoutingInstanceFilterSet
    filterset_form_class = forms.BGPRoutingInstanceFilterForm
    form_class = forms.BGPRoutingInstanceForm
    queryset = models.BGPRoutingInstance.objects.select_related("device", "autonomous_system", "router_id")
    table_class = tables.BGPRoutingInstanceTable


class PeerGroupTemplateUIViewSet(NautobotUIViewSet):
    """UI ViewSet for PeerGroupTemplate."""

    bulk_update_form_class = forms.PeerGroupTemplateBulkEditForm
    filterset_class = filters.PeerGroupTemplateFilterSet
    filterset_form_class = forms.PeerGroupTemplateFilterForm
    form_class = forms.PeerGroupTemplateForm
    queryset = models.PeerGroupTemplate.objects.select_related(
        "autonomous_system",
        "role",
        "secret",
    )
    table_class = tables.PeerGroupTemplateTable


class PeerGroupUIViewSet(NautobotUIViewSet):
    """UI ViewSet for PeerGroup."""

    bulk_update_form_class = forms.PeerGroupBulkEditForm
    filterset_class = filters.PeerGroupFilterSet
    filterset_form_class = forms.PeerGroupFilterForm
    form_class = forms.PeerGroupForm
    queryset = models.PeerGroup.objects.select_related("routing_instance", "vrf")
    table_class = tables.PeerGroupTable


class PeeringUIViewSet(NautobotUIViewSet):
    """UI ViewSet for Peering."""

    bulk_update_form_class = forms.PeeringBulkEditForm
    filterset_class = filters.PeeringFilterSet
    filterset_form_class = forms.PeeringFilterForm
    form_class = forms.PeeringForm
    queryset = models.Peering.objects.prefetch_related(
        "endpoints__routing_instance__device",
        "endpoints__autonomous_system",
        "endpoints__source_ip",
    )
    table_class = tables.PeeringTable
    object_detail_content = ObjectDetailContent(
        panels=[
            ObjectFieldsPanel(
                weight=100,
                section=SectionChoices.LEFT_HALF,
                fields="__all__",
            ),
            ObjectsTablePanel(
                weight=200,
                section=SectionChoices.FULL_WIDTH,
                table_class=tables.PeerEndpointTable,
                table_attribute="endpoints",
                related_field_name="peering",
                table_title="Peer Endpoints",
            ),
        ]
    )


class PeerEndpointUIViewSet(NautobotUIViewSet):
    """UI ViewSet for PeerEndpoint."""

    bulk_update_form_class = forms.PeerEndpointBulkEditForm
    filterset_class = filters.PeerEndpointFilterSet
    filterset_form_class = forms.PeerEndpointFilterForm
    form_class = forms.PeerEndpointForm
    queryset = models.PeerEndpoint.objects.select_related(
        "peering",
        "routing_instance",
        "routing_instance__device",
        "peer_group",
        "autonomous_system",
        "source_ip",
        "source_interface",
    )
    table_class = tables.PeerEndpointTable


class AddressFamilyUIViewSet(NautobotUIViewSet):
    """UI ViewSet for AddressFamily."""

    bulk_update_form_class = forms.AddressFamilyBulkEditForm
    filterset_class = filters.AddressFamilyFilterSet
    filterset_form_class = forms.AddressFamilyFilterForm
    form_class = forms.AddressFamilyForm
    queryset = models.AddressFamily.objects.select_related(
        "routing_instance",
        "import_policy",
        "export_policy",
    )
    table_class = tables.AddressFamilyTable


class RoutingPolicyUIViewSet(NautobotUIViewSet):
    """UI ViewSet for RoutingPolicy."""

    bulk_update_form_class = forms.RoutingPolicyBulkEditForm
    filterset_class = filters.RoutingPolicyFilterSet
    filterset_form_class = forms.RoutingPolicyFilterForm
    form_class = forms.RoutingPolicyForm
    queryset = models.RoutingPolicy.objects.all()
    table_class = tables.RoutingPolicyTable

    def get_extra_context(self, request, instance=None):
        context = super().get_extra_context(request, instance)
        if instance and instance.present_in_database:
            terms_table = tables.RoutingPolicyTermTable(instance.terms.all(), orderable=False)
            RequestConfig(request, paginate={"per_page": 25}).configure(terms_table)
            context["terms_table"] = terms_table
        return context


class RoutingPolicyTermUIViewSet(NautobotUIViewSet):
    """UI ViewSet for RoutingPolicyTerm."""

    bulk_update_form_class = forms.RoutingPolicyTermBulkEditForm
    filterset_class = filters.RoutingPolicyTermFilterSet
    filterset_form_class = forms.RoutingPolicyTermFilterForm
    form_class = forms.RoutingPolicyTermForm
    queryset = models.RoutingPolicyTerm.objects.select_related("policy")
    table_class = tables.RoutingPolicyTermTable


class PrefixListUIViewSet(NautobotUIViewSet):
    """UI ViewSet for PrefixList."""

    bulk_update_form_class = forms.PrefixListBulkEditForm
    filterset_class = filters.PrefixListFilterSet
    filterset_form_class = forms.PrefixListFilterForm
    form_class = forms.PrefixListForm
    queryset = models.PrefixList.objects.all()
    table_class = tables.PrefixListTable

    def get_extra_context(self, request, instance=None):
        context = super().get_extra_context(request, instance)
        if instance and instance.present_in_database:
            entries_table = tables.PrefixListEntryTable(instance.entries.all(), orderable=False)
            RequestConfig(request, paginate={"per_page": 25}).configure(entries_table)
            context["entries_table"] = entries_table
        return context


class PrefixListEntryUIViewSet(NautobotUIViewSet):
    """UI ViewSet for PrefixListEntry."""

    bulk_update_form_class = forms.PrefixListEntryBulkEditForm
    filterset_class = filters.PrefixListEntryFilterSet
    filterset_form_class = forms.PrefixListEntryFilterForm
    form_class = forms.PrefixListEntryForm
    queryset = models.PrefixListEntry.objects.select_related("prefix_list")
    table_class = tables.PrefixListEntryTable


class CommunityDimensionUIViewSet(NautobotUIViewSet):
    """UI ViewSet for CommunityDimension."""

    bulk_update_form_class = forms.CommunityDimensionBulkEditForm
    filterset_class = filters.CommunityDimensionFilterSet
    filterset_form_class = forms.CommunityDimensionFilterForm
    form_class = forms.CommunityDimensionForm
    queryset = models.CommunityDimension.objects.select_related("parent", "location")
    table_class = tables.CommunityDimensionTable


class ISISRoutingInstanceUIViewSet(NautobotUIViewSet):
    """UI ViewSet for ISISRoutingInstance."""

    bulk_update_form_class = forms.ISISRoutingInstanceBulkEditForm
    filterset_class = filters.ISISRoutingInstanceFilterSet
    filterset_form_class = forms.ISISRoutingInstanceFilterForm
    form_class = forms.ISISRoutingInstanceForm
    queryset = models.ISISRoutingInstance.objects.select_related("device", "protocol_authentication")
    table_class = tables.ISISRoutingInstanceTable

    def get_extra_context(self, request, instance=None):
        context = super().get_extra_context(request, instance)
        if instance and instance.present_in_database:
            isis_ifs = models.ISISInterface.objects.filter(interface__device=instance.device).select_related(
                "interface"
            )
            isis_table = tables.ISISInterfaceTable(isis_ifs, orderable=False)
            RequestConfig(request, paginate={"per_page": 25}).configure(isis_table)
            context["isis_table"] = isis_table
        return context


class ISISInterfaceUIViewSet(NautobotUIViewSet):
    """UI ViewSet for ISISInterface."""

    bulk_update_form_class = forms.ISISInterfaceBulkEditForm
    filterset_class = filters.ISISInterfaceFilterSet
    filterset_form_class = forms.ISISInterfaceFilterForm
    form_class = forms.ISISInterfaceForm
    queryset = models.ISISInterface.objects.select_related("interface", "interface__device")
    table_class = tables.ISISInterfaceTable


class MPLSInterfaceUIViewSet(NautobotUIViewSet):
    """UI ViewSet for MPLSInterface."""

    bulk_update_form_class = forms.MPLSInterfaceBulkEditForm
    filterset_class = filters.MPLSInterfaceFilterSet
    filterset_form_class = forms.MPLSInterfaceFilterForm
    form_class = forms.MPLSInterfaceForm
    queryset = models.MPLSInterface.objects.select_related("interface", "interface__device")
    table_class = tables.MPLSInterfaceTable


class RSVPInterfaceUIViewSet(NautobotUIViewSet):
    """UI ViewSet for RSVPInterface."""

    bulk_update_form_class = forms.RSVPInterfaceBulkEditForm
    filterset_class = filters.RSVPInterfaceFilterSet
    filterset_form_class = forms.RSVPInterfaceFilterForm
    form_class = forms.RSVPInterfaceForm
    queryset = models.RSVPInterface.objects.select_related("interface", "interface__device")
    table_class = tables.RSVPInterfaceTable


class MACsecAssociationUIViewSet(NautobotUIViewSet):
    """UI ViewSet for MACsecAssociation."""

    bulk_update_form_class = forms.MACsecAssociationBulkEditForm
    filterset_class = filters.MACsecAssociationFilterSet
    filterset_form_class = forms.MACsecAssociationFilterForm
    form_class = forms.MACsecAssociationForm
    queryset = models.MACsecAssociation.objects.all()
    table_class = tables.MACsecAssociationTable


class TransportClassUIViewSet(NautobotUIViewSet):
    """UI ViewSet for TransportClass."""

    bulk_update_form_class = forms.TransportClassBulkEditForm
    filterset_class = filters.TransportClassFilterSet
    filterset_form_class = forms.TransportClassFilterForm
    form_class = forms.TransportClassForm
    queryset = models.TransportClass.objects.all()
    table_class = tables.TransportClassTable


class MPLSTemplateUIViewSet(NautobotUIViewSet):
    """UI ViewSet for MPLSTemplate."""

    bulk_update_form_class = forms.MPLSTemplateBulkEditForm
    filterset_class = filters.MPLSTemplateFilterSet
    filterset_form_class = forms.MPLSTemplateFilterForm
    form_class = forms.MPLSTemplateForm
    queryset = models.MPLSTemplate.objects.select_related("transport_class")
    table_class = tables.MPLSTemplateTable


class LabelSwitchedPathUIViewSet(NautobotUIViewSet):
    """UI ViewSet for LabelSwitchedPath."""

    bulk_update_form_class = forms.LabelSwitchedPathBulkEditForm
    filterset_class = filters.LabelSwitchedPathFilterSet
    filterset_form_class = forms.LabelSwitchedPathFilterForm
    form_class = forms.LabelSwitchedPathForm
    queryset = models.LabelSwitchedPath.objects.select_related("device", "template")
    table_class = tables.LabelSwitchedPathTable


class EVPNPWServiceUIViewSet(NautobotUIViewSet):
    """UI ViewSet for EVPNPWService."""

    bulk_update_form_class = forms.EVPNPWServiceBulkEditForm
    filterset_class = filters.EVPNPWServiceFilterSet
    filterset_form_class = forms.EVPNPWServiceFilterForm
    form_class = forms.EVPNPWServiceForm
    queryset = models.EVPNPWService.objects.select_related(
        "interface",
        "interface__device",
        "remote_pe",
        "circuit",
        "transport_class",
    )
    table_class = tables.EVPNPWServiceTable
