# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Signal handlers for the routing plugin."""

import logging

from django.contrib.contenttypes.models import ContentType
from nautobot.extras.models import Status

from nautobot_app_routing import models

logger = logging.getLogger(__name__)

ROUTING_MODELS = (
    models.AutonomousSystem,
    models.BGPRoutingInstance,
    models.Peering,
    models.TransportClass,
    models.LabelSwitchedPath,
    models.EVPNPWService,
)
DEFAULT_STATUSES = ("Active", "Planned", "Deprecated")


def post_migrate_create_defaults(*args, **kwargs):  # noqa: ARG001
    """Attach routing model content types to statuses."""
    logger.info("Linking routing models to default statuses")
    for model in ROUTING_MODELS:
        content_type = ContentType.objects.get_for_model(model)
        for status_name in DEFAULT_STATUSES:
            _ensure_status(status_name, content_type)


def _ensure_status(name, content_type):
    status, _created = Status.objects.get_or_create(name=name)
    status.content_types.add(content_type)
