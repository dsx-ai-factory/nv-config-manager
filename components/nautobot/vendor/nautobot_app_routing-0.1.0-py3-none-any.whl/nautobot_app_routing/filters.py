# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Filters for the routing plugin."""

import django_filters
from nautobot.apps.filters import NautobotFilterSet, SearchFilter
from nautobot.dcim.models import Device

from nautobot_app_routing import models
from nautobot_app_routing.choices import (
    AddressFamilyChoices,
    CommunityKindChoices,
    LSPClassChoices,
    PolicyActionChoices,
)


class AutonomousSystemFilterSet(NautobotFilterSet):
    """FilterSet for AutonomousSystem."""

    q = SearchFilter(filter_predicates={"description": "icontains"})

    class Meta:
        model = models.AutonomousSystem
        fields = ["id", "asn", "provider", "status"]


class BGPRoutingInstanceFilterSet(NautobotFilterSet):
    """FilterSet for BGPRoutingInstance."""

    q = SearchFilter(filter_predicates={"description": "icontains"})

    class Meta:
        model = models.BGPRoutingInstance
        fields = ["id", "device", "autonomous_system", "status"]


class PeerGroupTemplateFilterSet(NautobotFilterSet):
    """FilterSet for PeerGroupTemplate."""

    q = SearchFilter(filter_predicates={"name": "icontains", "description": "icontains"})

    class Meta:
        model = models.PeerGroupTemplate
        fields = ["id", "name", "enabled", "role", "autonomous_system"]


class PeerGroupFilterSet(NautobotFilterSet):
    """FilterSet for PeerGroup."""

    q = SearchFilter(filter_predicates={"name": "icontains", "description": "icontains"})

    class Meta:
        model = models.PeerGroup
        fields = ["id", "name", "routing_instance", "vrf", "enabled"]


class PeeringFilterSet(NautobotFilterSet):
    """FilterSet for Peering."""

    class Meta:
        model = models.Peering
        fields = ["id", "status"]


class PeerEndpointFilterSet(NautobotFilterSet):
    """FilterSet for PeerEndpoint."""

    q = SearchFilter(filter_predicates={"description": "icontains"})

    class Meta:
        model = models.PeerEndpoint
        fields = [
            "id",
            "peering",
            "routing_instance",
            "peer_group",
            "autonomous_system",
            "source_ip",
            "source_interface",
            "enabled",
        ]


class AddressFamilyFilterSet(NautobotFilterSet):
    """FilterSet for AddressFamily."""

    class Meta:
        model = models.AddressFamily
        fields = ["id", "routing_instance", "afi_safi", "import_policy", "export_policy"]


class RoutingPolicyFilterSet(NautobotFilterSet):
    """FilterSet for RoutingPolicy."""

    q = SearchFilter(filter_predicates={"name": "icontains", "description": "icontains"})
    default_action = django_filters.MultipleChoiceFilter(choices=PolicyActionChoices)

    class Meta:
        model = models.RoutingPolicy
        fields = ["id", "name", "default_action"]


class RoutingPolicyTermFilterSet(NautobotFilterSet):
    """FilterSet for RoutingPolicyTerm."""

    q = SearchFilter(filter_predicates={"name": "icontains", "from_policy": "icontains"})
    policy = django_filters.ModelMultipleChoiceFilter(queryset=models.RoutingPolicy.objects.all())

    class Meta:
        model = models.RoutingPolicyTerm
        fields = ["id", "policy", "name", "sequence"]


class PrefixListFilterSet(NautobotFilterSet):
    """FilterSet for PrefixList."""

    q = SearchFilter(filter_predicates={"name": "icontains"})
    address_family = django_filters.MultipleChoiceFilter(choices=AddressFamilyChoices)

    class Meta:
        model = models.PrefixList
        fields = ["id", "name", "address_family"]


class PrefixListEntryFilterSet(NautobotFilterSet):
    """FilterSet for PrefixListEntry."""

    q = SearchFilter(filter_predicates={"prefix": "icontains"})
    prefix_list = django_filters.ModelMultipleChoiceFilter(queryset=models.PrefixList.objects.all())

    class Meta:
        model = models.PrefixListEntry
        fields = ["id", "prefix_list", "prefix", "match"]


class CommunityDimensionFilterSet(NautobotFilterSet):
    """FilterSet for CommunityDimension."""

    q = SearchFilter(filter_predicates={"code": "icontains", "community_id": "icontains"})
    kind = django_filters.MultipleChoiceFilter(choices=CommunityKindChoices)
    parent = django_filters.ModelMultipleChoiceFilter(queryset=models.CommunityDimension.objects.all())

    class Meta:
        model = models.CommunityDimension
        fields = ["id", "kind", "code", "community_id", "parent", "location"]


class ISISRoutingInstanceFilterSet(NautobotFilterSet):
    """FilterSet for ISISRoutingInstance."""

    q = SearchFilter(filter_predicates={"net": "icontains"})

    class Meta:
        model = models.ISISRoutingInstance
        fields = ["id", "device", "net"]


class ISISInterfaceFilterSet(NautobotFilterSet):
    """FilterSet for ISISInterface."""

    q = SearchFilter(filter_predicates={"interface__name": "icontains"})
    device = django_filters.ModelMultipleChoiceFilter(
        field_name="interface__device",
        queryset=Device.objects.all(),
    )

    class Meta:
        model = models.ISISInterface
        fields = ["id", "interface", "metric", "level", "passive"]


class MPLSInterfaceFilterSet(NautobotFilterSet):
    """FilterSet for MPLSInterface."""

    q = SearchFilter(filter_predicates={"interface__name": "icontains"})
    device = django_filters.ModelMultipleChoiceFilter(
        field_name="interface__device",
        queryset=Device.objects.all(),
    )

    class Meta:
        model = models.MPLSInterface
        fields = ["id", "interface"]


class RSVPInterfaceFilterSet(NautobotFilterSet):
    """FilterSet for RSVPInterface."""

    q = SearchFilter(filter_predicates={"interface__name": "icontains"})
    device = django_filters.ModelMultipleChoiceFilter(
        field_name="interface__device",
        queryset=Device.objects.all(),
    )

    class Meta:
        model = models.RSVPInterface
        fields = ["id", "interface", "link_protection"]


class MACsecAssociationFilterSet(NautobotFilterSet):
    """FilterSet for MACsecAssociation."""

    q = SearchFilter(filter_predicates={"name": "icontains"})

    class Meta:
        model = models.MACsecAssociation
        fields = ["id", "name", "mode", "include_sci"]


class TransportClassFilterSet(NautobotFilterSet):
    """FilterSet for TransportClass."""

    q = SearchFilter(filter_predicates={"name": "icontains"})
    lsp_class = django_filters.MultipleChoiceFilter(choices=LSPClassChoices)

    class Meta:
        model = models.TransportClass
        fields = ["id", "name", "lsp_class", "color", "status"]


class MPLSTemplateFilterSet(NautobotFilterSet):
    """FilterSet for MPLSTemplate."""

    q = SearchFilter(filter_predicates={"name": "icontains", "description": "icontains"})

    class Meta:
        model = models.MPLSTemplate
        fields = ["id", "name", "transport_class"]


class LabelSwitchedPathFilterSet(NautobotFilterSet):
    """FilterSet for LabelSwitchedPath."""

    q = SearchFilter(filter_predicates={"name": "icontains"})

    class Meta:
        model = models.LabelSwitchedPath
        fields = ["id", "name", "device", "template", "status"]


class EVPNPWServiceFilterSet(NautobotFilterSet):
    """FilterSet for EVPNPWService."""

    q = SearchFilter(filter_predicates={"name": "icontains", "route_distinguisher": "icontains"})

    class Meta:
        model = models.EVPNPWService
        fields = [
            "id",
            "name",
            "local_service_id",
            "remote_service_id",
            "interface",
            "remote_pe",
            "circuit",
            "status",
        ]
