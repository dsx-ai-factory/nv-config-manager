# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Navigation menu items for the routing plugin."""

from nautobot.apps.ui import NavMenuAddButton, NavMenuGroup, NavMenuItem, NavMenuTab

APP = "nautobot_app_routing"
MENU_TAB = "Backbone Routing"


def _item(model, name):
    """Build a list menu item with its add button for a routing model."""
    return NavMenuItem(
        link=f"plugins:{APP}:{model}_list",
        name=name,
        permissions=[f"{APP}.view_{model}"],
        buttons=(
            NavMenuAddButton(
                link=f"plugins:{APP}:{model}_add",
                permissions=[f"{APP}.add_{model}"],
            ),
        ),
    )


menu_items = (
    NavMenuTab(
        name=MENU_TAB,
        groups=(
            NavMenuGroup(
                name="IS-IS",
                items=(
                    _item("isisroutinginstance", "Routing Instances"),
                    _item("isisinterface", "Interfaces"),
                ),
            ),
            NavMenuGroup(
                name="MPLS and RSVP",
                items=(
                    _item("labelswitchedpath", "LSPs"),
                    _item("mplstemplate", "LSP Templates"),
                    _item("transportclass", "Transport Classes"),
                    _item("mplsinterface", "MPLS Interfaces"),
                    _item("rsvpinterface", "RSVP Interfaces"),
                ),
            ),
            NavMenuGroup(
                name="Services",
                items=(_item("evpnpwservice", "EVPN VPWS Services"),),
            ),
            NavMenuGroup(
                name="MACsec",
                items=(_item("macsecassociation", "Associations"),),
            ),
            NavMenuGroup(
                name="BGP",
                items=(
                    _item("autonomoussystem", "Autonomous Systems"),
                    _item("bgproutinginstance", "Routing Instances"),
                    _item("peergrouptemplate", "Peer Group Templates"),
                    _item("peergroup", "Peer Groups"),
                    _item("peering", "Peerings"),
                    _item("peerendpoint", "Peer Endpoints"),
                    _item("addressfamily", "Address Families"),
                ),
            ),
            NavMenuGroup(
                name="Policies",
                items=(
                    _item("routingpolicy", "Routing Policies"),
                    _item("routingpolicyterm", "Policy Terms"),
                    _item("prefixlist", "Prefix Lists"),
                    _item("prefixlistentry", "Prefix List Entries"),
                    _item("communitydimension", "Communities"),
                ),
            ),
        ),
    ),
)
