# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Tests for routing plugin models."""

from django.apps import apps
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.test import TestCase
from nautobot.dcim.models import Device, DeviceType, Interface, Location, LocationType, Manufacturer
from nautobot.extras.models import Role, Status

from nautobot_app_routing import choices, models
from nautobot_app_routing.communities import NVIDIA_ASN, loc_community_for_device


def make_location(name="AMS0A"):
    location_type, _ = LocationType.objects.get_or_create(name="PoP")
    location_type.content_types.add(ContentType.objects.get_for_model(Device))
    return Location.objects.create(
        name=name,
        location_type=location_type,
        status=Status.objects.get_for_model(Location).first(),
    )


def make_device(location, name="AMS0A-BBR-01", model="PTX-test"):
    manufacturer, _ = Manufacturer.objects.get_or_create(name="Juniper-test")
    device_type, _ = DeviceType.objects.get_or_create(manufacturer=manufacturer, model=model)
    role, _ = Role.objects.get_or_create(name="Backbone Router")
    role.content_types.add(ContentType.objects.get_for_model(Device))
    return Device.objects.create(
        name=name,
        device_type=device_type,
        location=location,
        status=Status.objects.get_for_model(Device).first(),
        role=role,
    )


def make_interface(device, name="ae100"):
    return Interface.objects.create(
        device=device,
        name=name,
        type="lag",
        status=Status.objects.get_for_model(Interface).first(),
    )


BGP_PLUGIN_REVERSE_NAMES = {
    "autonomous_systems",
    "autonomoussystem_set",
    "bgp_peer_endpoints",
    "bgp_peer_group_templates",
    "bgp_peer_groups",
    "bgp_peerings",
    "bgp_routing_instances",
    "bgproutinginstance_set",
    "peerendpoint_set",
    "peergroup_set",
    "peergrouptemplate_set",
}


class CoreOverlapTests(TestCase):
    """The app must not re-model what dcim already provides."""

    def test_app_does_not_define_link_or_termination_models(self):
        model_names = {model.__name__ for model in apps.get_app_config("nautobot_app_routing").get_models()}
        self.assertNotIn("Link", model_names)
        self.assertNotIn("LinkTermination", model_names)
        self.assertNotIn("QoSProfile", model_names)

    def test_protocol_intent_anchors_on_core_interface(self):
        for model in (models.ISISInterface, models.MPLSInterface, models.RSVPInterface):
            self.assertIs(model._meta.get_field("interface").related_model, Interface)

    def test_every_routing_model_supports_tags_without_dynamic_groups(self):
        for model in apps.get_app_config("nautobot_app_routing").get_models():
            with self.subTest(model=model.__name__):
                self.assertIsNotNone(model._meta.get_field("tags"))
                self.assertFalse(model.is_dynamic_group_associable_model)

    def test_ui_labels_preserve_capitalization_and_acronyms(self):
        expected_field_labels = {
            (models.EVPNPWService, "local_service_id"): "Local Service ID",
            (models.EVPNPWService, "remote_service_id"): "Remote Service ID",
            (models.EVPNPWService, "remote_pe"): "Remote PE",
            (models.EVPNPWService, "remote_pe_address"): "Remote PE Address",
            (models.EVPNPWService, "route_distinguisher"): "Route Distinguisher",
            (models.ISISRoutingInstance, "protocol_authentication"): "LSP Authentication",
            (models.LabelSwitchedPath, "to_address"): "To Address",
        }
        for (model, field_name), label in expected_field_labels.items():
            with self.subTest(model=model.__name__, field=field_name):
                self.assertEqual(str(model._meta.get_field(field_name).verbose_name), label)
        self.assertEqual(models.LabelSwitchedPath._meta.verbose_name_plural, "LSPs")
        self.assertEqual(models.MPLSTemplate._meta.verbose_name_plural, "LSP Templates")

    def test_bgp_models_do_not_reuse_bgp_plugin_reverse_names(self):
        bgp_models = (
            models.AddressFamily,
            models.AutonomousSystem,
            models.BGPRoutingInstance,
            models.PeerEndpoint,
            models.PeerGroup,
            models.PeerGroupTemplate,
            models.Peering,
        )
        clashes = []
        for model in bgp_models:
            for field in [*model._meta.fields, *model._meta.many_to_many]:
                remote = getattr(field, "remote_field", None)
                related_name = getattr(remote, "related_name", None)
                if related_name in BGP_PLUGIN_REVERSE_NAMES:
                    clashes.append(f"{model.__name__}.{field.name}={related_name}")
        self.assertEqual(clashes, [])


class ISISRoutingInstanceTests(TestCase):
    """Device IS-IS instance requires a NET."""

    def setUp(self):
        self.device = make_device(make_location())

    def test_net_is_required(self):
        instance = models.ISISRoutingInstance(device=self.device, net="")
        with self.assertRaises(ValidationError):
            instance.full_clean()

    def test_net_is_stored(self):
        instance = models.ISISRoutingInstance.objects.create(
            device=self.device,
            net="49.0039.8037.0000.0100.1602.4024.00",
        )
        self.assertIn("49.0039", instance.net)


class ISISInterfaceTests(TestCase):
    """IS-IS metric intent is one row per core Interface."""

    def setUp(self):
        self.interface = make_interface(make_device(make_location()))

    def test_metric_and_level_defaults(self):
        isis = models.ISISInterface.objects.create(interface=self.interface, metric=890)
        self.assertEqual(isis.metric, 890)
        self.assertEqual(isis.level, choices.ISISLevelChoices.LEVEL_2)
        self.assertFalse(isis.passive)

    def test_one_row_per_interface(self):
        models.ISISInterface.objects.create(interface=self.interface)
        with self.assertRaises(IntegrityError), transaction.atomic():
            models.ISISInterface.objects.create(interface=self.interface)


class CommunityDimensionTests(TestCase):
    """Community hierarchy and loc_community derivation."""

    def test_parent_kind_and_loc_community(self):
        continent = models.CommunityDimension.objects.create(
            kind=choices.CommunityKindChoices.CONTINENT,
            code="EMEIA",
            community_id="4...",
        )
        region = models.CommunityDimension.objects.create(
            kind=choices.CommunityKindChoices.REGION,
            code="WESTEU",
            community_id="41..",
            parent=continent,
        )
        metro = models.CommunityDimension.objects.create(
            kind=choices.CommunityKindChoices.METRO,
            code="AMS",
            community_id="412.",
            parent=region,
        )
        location = make_location()
        models.CommunityDimension.objects.create(
            kind=choices.CommunityKindChoices.SITE,
            code="AMS0A",
            community_id="4121",
            parent=metro,
            location=location,
        )
        device = make_device(location, name="AMS0A-BBR-COMM")
        self.assertEqual(region.parent, continent)
        self.assertEqual(loc_community_for_device(device), f"{NVIDIA_ASN}:10:4121")


class PrefixListEntryTests(TestCase):
    """Prefix list entries store family and match qualifier."""

    def test_entry_match_and_uniqueness(self):
        prefix_list = models.PrefixList.objects.create(
            name="DEFAULT_V4",
            address_family=choices.AddressFamilyChoices.IPV4,
        )
        models.PrefixListEntry.objects.create(
            prefix_list=prefix_list,
            prefix="0.0.0.0/0",
            match=choices.PrefixMatchChoices.EXACT,
        )
        with self.assertRaises(IntegrityError), transaction.atomic():
            models.PrefixListEntry.objects.create(
                prefix_list=prefix_list,
                prefix="0.0.0.0/0",
                match=choices.PrefixMatchChoices.EXACT,
            )


class RoutingPolicyTermTests(TestCase):
    """Policy terms are ordered rows, not JSON."""

    def test_terms_order_by_sequence(self):
        policy = models.RoutingPolicy.objects.create(
            name="GCP_EXPORT",
            default_action=choices.PolicyActionChoices.REJECT,
        )
        models.RoutingPolicyTerm.objects.create(
            policy=policy,
            name="TERM_020",
            sequence=20,
            from_policy="DENY_DEFAULT",
            then_action=choices.PolicyActionChoices.REJECT,
        )
        models.RoutingPolicyTerm.objects.create(
            policy=policy,
            name="TERM_010",
            sequence=10,
            from_policy="DENY_DEFAULT && SEND_NGC_GCP_PREFIXES",
            then_action=choices.PolicyActionChoices.ACCEPT,
        )
        self.assertEqual(list(policy.terms.values_list("name", flat=True)), ["TERM_010", "TERM_020"])


class EVPNPWServiceTests(TestCase):
    """VPWS services need a far-end PE identity."""

    def setUp(self):
        location = make_location()
        self.device = make_device(location)
        self.remote = make_device(location, name="LHR0A2-BBR-01", model="PTX-remote")
        self.interface = make_interface(self.device, name="et-0/0/5")
        self.status = Status.objects.get_for_model(models.EVPNPWService).first() or Status.objects.create(
            name="VPWS Active"
        )

    def _service(self, **overrides):
        fields = {
            "name": "PW-AMS-LHR-001",
            "local_service_id": 100001,
            "remote_service_id": 100002,
            "interface": self.interface,
            "route_distinguisher": "398037:100001",
            "import_target": "398037:100002",
            "export_target": "398037:100001",
            "status": self.status,
        }
        fields.update(overrides)
        return models.EVPNPWService(**fields)

    def test_remote_pe_identity_is_required(self):
        with self.assertRaises(ValidationError):
            self._service().clean()

    def test_remote_pe_device_satisfies_identity(self):
        service = self._service(remote_pe=self.remote)
        service.clean()
        service.save()
        self.assertEqual(service.remote_pe, self.remote)

    def test_remote_pe_address_satisfies_identity(self):
        service = self._service(remote_pe_address="10.16.11.201")
        service.clean()
        service.save()
        self.assertEqual(service.remote_pe_address, "10.16.11.201")


class MACsecAssociationTests(TestCase):
    """MACsec CA policy binds to core interfaces."""

    def test_association_holds_multiple_interfaces(self):
        location = make_location()
        device = make_device(location)
        association = models.MACsecAssociation.objects.create(
            name="MACSEC-AMS0A-IAD0A",
            mode=choices.MACsecModeChoices.PRESHARED,
        )
        association.interfaces.add(
            make_interface(device, name="et-0/0/34:0"),
            make_interface(device, name="et-0/0/34:1"),
        )
        self.assertEqual(association.interfaces.count(), 2)
        self.assertFalse(association.include_sci)
