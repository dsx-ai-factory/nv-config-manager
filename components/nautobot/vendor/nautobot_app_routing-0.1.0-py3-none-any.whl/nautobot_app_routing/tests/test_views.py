# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Smoke tests that every navigable routing view renders."""

from django.test import Client, TestCase
from django.urls import reverse
from nautobot.users.models import User

from nautobot_app_routing import navigation

BGP_PLUGIN_MENU_TAB = "Routing"

NAV_MODELS = (
    "isisroutinginstance",
    "isisinterface",
    "mplsinterface",
    "rsvpinterface",
    "transportclass",
    "mplstemplate",
    "labelswitchedpath",
    "evpnpwservice",
    "macsecassociation",
    "autonomoussystem",
    "bgproutinginstance",
    "peergrouptemplate",
    "peergroup",
    "peering",
    "peerendpoint",
    "addressfamily",
    "routingpolicy",
    "routingpolicyterm",
    "prefixlist",
    "prefixlistentry",
    "communitydimension",
)


class RoutingViewSmokeTests(TestCase):
    """Every model in the Routing nav tab has a working list and add view."""

    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_superuser(username="routing-smoke", password="smoke")  # noqa: S106

    def setUp(self):
        self.client = Client()
        self.client.force_login(self.user)

    def test_list_views_render(self):
        for model in NAV_MODELS:
            with self.subTest(model=model):
                url = reverse(f"plugins:nautobot_app_routing:{model}_list")
                self.assertEqual(self.client.get(url).status_code, 200)

    def test_add_views_render(self):
        for model in NAV_MODELS:
            with self.subTest(model=model):
                url = reverse(f"plugins:nautobot_app_routing:{model}_add")
                self.assertEqual(self.client.get(url).status_code, 200)
