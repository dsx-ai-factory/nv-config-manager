# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Tests for seed_routing_demo management command."""

from django.core.management import call_command
from django.test import TestCase
from nautobot.dcim.models import Cable, Interface

from nautobot_app_routing import models
from nautobot_app_routing.communities import loc_community_for_device


class SeedRoutingDemoTests(TestCase):
    """Seed command creates protocol intent on top of core topology."""

    @classmethod
    def setUpTestData(cls):
        call_command("seed_routing_demo")

    def test_protocol_intent_is_seeded(self):
        self.assertGreaterEqual(models.ISISRoutingInstance.objects.count(), 3)
        self.assertGreaterEqual(models.ISISInterface.objects.count(), 4)
        self.assertGreaterEqual(models.MPLSInterface.objects.count(), 2)
        self.assertGreaterEqual(models.RSVPInterface.objects.count(), 2)
        self.assertGreaterEqual(models.EVPNPWService.objects.count(), 2)
        self.assertGreaterEqual(models.MACsecAssociation.objects.count(), 1)
        self.assertGreaterEqual(models.CommunityDimension.objects.count(), 10)
        self.assertGreaterEqual(models.PrefixListEntry.objects.count(), 4)
        self.assertGreaterEqual(models.RoutingPolicyTerm.objects.count(), 2)

    def test_topology_uses_core_cables_and_circuits(self):
        self.assertGreaterEqual(Cable.objects.count(), 5)
        member = Interface.objects.get(device__name="AMS0A-BBR-01", name="et-0/0/34:0")
        self.assertIsNotNone(member.cable)
        self.assertEqual(member.cable.termination_b.circuit.cid, "NVBV1/WAVE/169213")

    def test_profiles_are_seeded_as_interface_roles(self):
        ae100 = Interface.objects.get(device__name="AMS0A-BBR-01", name="ae100")
        self.assertEqual(ae100.role.name, "Backbone intra-site")

    def test_isis_metrics_match_render_context(self):
        instance = models.ISISRoutingInstance.objects.get(device__name="AMS0A-BBR-01")
        self.assertTrue(instance.net.startswith("49."))
        self.assertEqual(loc_community_for_device(instance.device), "398037:10:4121")
        metrics = {
            isis.interface.name: isis.metric
            for isis in models.ISISInterface.objects.filter(interface__device=instance.device)
        }
        self.assertEqual(metrics["ae100"], 10)
        self.assertEqual(metrics["ae1200"], 890)


class SeedRoutingDemoFlushTests(TestCase):
    """Reseeding after a flush is idempotent."""

    def test_flush_reseeds_same_counts(self):
        call_command("seed_routing_demo")
        before = {
            "isis": models.ISISInterface.objects.count(),
            "vpws": models.EVPNPWService.objects.count(),
            "terms": models.RoutingPolicyTerm.objects.count(),
            "dimensions": models.CommunityDimension.objects.count(),
        }
        call_command("seed_routing_demo", flush=True)
        after = {
            "isis": models.ISISInterface.objects.count(),
            "vpws": models.EVPNPWService.objects.count(),
            "terms": models.RoutingPolicyTerm.objects.count(),
            "dimensions": models.CommunityDimension.objects.count(),
        }
        self.assertEqual(before, after)
