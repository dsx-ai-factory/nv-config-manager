# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Tests for the routing plugin REST API."""

from django.urls import reverse
from nautobot.core.testing import APITestCase
from rest_framework import status

from nautobot_app_routing import models
from nautobot_app_routing.tests.test_models import make_device, make_interface, make_location

EXPECTED_ROUTES = {
    "address-families",
    "autonomous-systems",
    "bgp-routing-instances",
    "communities",
    "evpn-vpws",
    "isis-interfaces",
    "isis-routing-instances",
    "lsps",
    "macsec-associations",
    "mpls-interfaces",
    "mpls-templates",
    "peer-endpoints",
    "peer-group-templates",
    "peer-groups",
    "peerings",
    "prefix-list-entries",
    "prefix-lists",
    "routing-policies",
    "routing-policy-terms",
    "rsvp-interfaces",
    "transport-classes",
}


class RoutingAPITest(APITestCase):
    """Exercise API discovery and the NVCM IS-IS workflow operations."""

    @classmethod
    def setUpTestData(cls):
        cls.interface = make_interface(make_device(make_location()))

    def setUp(self):
        super().setUp()
        self.user.is_superuser = True
        self.user.save()
        self.api_root = reverse("plugins-api:nautobot_app_routing-api:api-root")

    def test_api_root_exposes_every_routing_model(self):
        response = self.client.get(self.api_root, **self.header)

        self.assertHttpStatus(response, status.HTTP_200_OK)
        self.assertEqual(set(response.data), EXPECTED_ROUTES)

    def test_all_collection_endpoints_are_available(self):
        root_response = self.client.get(self.api_root, **self.header)

        for route in EXPECTED_ROUTES:
            with self.subTest(route=route):
                response = self.client.get(root_response.data[route], **self.header)
                self.assertHttpStatus(response, status.HTTP_200_OK)

    def test_isis_interface_can_be_created_and_updated(self):
        collection_url = f"{self.api_root}isis-interfaces/"
        create_response = self.client.post(
            collection_url,
            {
                "interface": str(self.interface.pk),
                "metric": 890,
                "level": "2",
                "passive": False,
            },
            format="json",
            **self.header,
        )

        self.assertHttpStatus(create_response, status.HTTP_201_CREATED)
        instance = models.ISISInterface.objects.get(interface=self.interface)
        detail_url = f"{collection_url}{instance.pk}/"
        update_response = self.client.patch(
            detail_url,
            {"metric": 16_777_214},
            format="json",
            **self.header,
        )

        self.assertHttpStatus(update_response, status.HTTP_200_OK)
        instance.refresh_from_db()
        self.assertEqual(instance.metric, 16_777_214)

    def test_isis_interface_rejects_invalid_level(self):
        response = self.client.post(
            f"{self.api_root}isis-interfaces/",
            {
                "interface": str(self.interface.pk),
                "metric": 10,
                "level": "3",
            },
            format="json",
            **self.header,
        )

        self.assertHttpStatus(response, status.HTTP_400_BAD_REQUEST)
        self.assertIn("level", response.data)

    def test_isis_interfaces_filter_by_device(self):
        models.ISISInterface.objects.create(interface=self.interface, metric=100)

        response = self.client.get(
            f"{self.api_root}isis-interfaces/?device={self.interface.device_id}",
            **self.header,
        )

        self.assertHttpStatus(response, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)
