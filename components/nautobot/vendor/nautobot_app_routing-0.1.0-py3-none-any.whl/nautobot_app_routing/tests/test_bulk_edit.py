# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Bulk edit forms and views for every routing model."""

from django.contrib.contenttypes.models import ContentType
from django.test import Client, TestCase
from django.urls import reverse
from nautobot.core.utils.lookup import get_form_for_model
from nautobot.users.models import ObjectPermission, User

from nautobot_app_routing import choices, models, views
from nautobot_app_routing.tests.test_models import make_device, make_interface, make_location

BULK_EDIT_VIEWSETS = (
    views.AutonomousSystemUIViewSet,
    views.BGPRoutingInstanceUIViewSet,
    views.PeerGroupTemplateUIViewSet,
    views.PeerGroupUIViewSet,
    views.PeeringUIViewSet,
    views.PeerEndpointUIViewSet,
    views.AddressFamilyUIViewSet,
    views.RoutingPolicyUIViewSet,
    views.RoutingPolicyTermUIViewSet,
    views.PrefixListUIViewSet,
    views.PrefixListEntryUIViewSet,
    views.CommunityDimensionUIViewSet,
    views.ISISRoutingInstanceUIViewSet,
    views.ISISInterfaceUIViewSet,
    views.MPLSInterfaceUIViewSet,
    views.RSVPInterfaceUIViewSet,
    views.MACsecAssociationUIViewSet,
    views.TransportClassUIViewSet,
    views.MPLSTemplateUIViewSet,
    views.LabelSwitchedPathUIViewSet,
    views.EVPNPWServiceUIViewSet,
)


class BulkEditWiringTests(TestCase):
    """Every routing viewset can build a bulk edit form.

    A missing bulk_update_form_class makes Nautobot call None and raise
    "'NoneType' object is not callable" when an operator uses Edit Selected.
    """

    def test_every_viewset_declares_a_bulk_update_form(self):
        for viewset in BULK_EDIT_VIEWSETS:
            with self.subTest(viewset=viewset.__name__):
                self.assertIsNotNone(getattr(viewset, "bulk_update_form_class", None))

    def test_bulk_update_form_is_instantiable_the_way_nautobot_calls_it(self):
        for viewset in BULK_EDIT_VIEWSETS:
            with self.subTest(viewset=viewset.__name__):
                model = viewset.queryset.model
                form = viewset.bulk_update_form_class(model, {}, edit_all=False)
                self.assertEqual(form.model, model)

    def test_bulk_update_form_targets_its_own_model(self):
        for viewset in BULK_EDIT_VIEWSETS:
            with self.subTest(viewset=viewset.__name__):
                form = viewset.bulk_update_form_class(viewset.queryset.model, {})
                self.assertIs(form.fields["pk"].queryset.model, viewset.queryset.model)

    def test_bulk_edit_job_can_resolve_each_form_by_name(self):
        """The background job looks the form up by convention, not by viewset attribute."""
        for viewset in BULK_EDIT_VIEWSETS:
            with self.subTest(viewset=viewset.__name__):
                self.assertIs(
                    get_form_for_model(viewset.queryset.model, form_prefix="BulkEdit"),
                    viewset.bulk_update_form_class,
                )

    def test_nullable_fields_exist_on_the_form_or_model(self):
        for viewset in BULK_EDIT_VIEWSETS:
            with self.subTest(viewset=viewset.__name__):
                form = viewset.bulk_update_form_class(viewset.queryset.model, {})
                model_fields = {field.name for field in viewset.queryset.model._meta.get_fields()}
                for name in form.nullable_fields:
                    self.assertIn(name, set(form.fields) | model_fields)

    def test_pk_is_the_only_required_field(self):
        """Nautobot targets the selected rows through pk; every change is opt-in."""
        for viewset in BULK_EDIT_VIEWSETS:
            with self.subTest(viewset=viewset.__name__):
                form = viewset.bulk_update_form_class(viewset.queryset.model, {})
                required = [name for name, field in form.fields.items() if field.required]
                self.assertEqual(required, ["pk"])

    def test_unique_fields_are_not_offered(self):
        """Bulk setting a unique field would collide across the selected rows."""
        unique_by_viewset = {
            views.AutonomousSystemUIViewSet: "asn",
            views.PeerGroupTemplateUIViewSet: "name",
            views.RoutingPolicyUIViewSet: "name",
            views.PrefixListUIViewSet: "name",
            views.PrefixListEntryUIViewSet: "prefix",
            views.MACsecAssociationUIViewSet: "name",
            views.TransportClassUIViewSet: "name",
            views.MPLSTemplateUIViewSet: "name",
            views.EVPNPWServiceUIViewSet: "name",
        }
        for viewset, field_name in unique_by_viewset.items():
            with self.subTest(viewset=viewset.__name__):
                form = viewset.bulk_update_form_class(viewset.queryset.model, {})
                self.assertNotIn(field_name, form.fields)

    def test_interface_scoped_models_do_not_offer_the_interface(self):
        """The owning interface is the object's identity, not a bulk-editable attribute."""
        for viewset in (
            views.ISISInterfaceUIViewSet,
            views.MPLSInterfaceUIViewSet,
            views.RSVPInterfaceUIViewSet,
            views.EVPNPWServiceUIViewSet,
        ):
            with self.subTest(viewset=viewset.__name__):
                form = viewset.bulk_update_form_class(viewset.queryset.model, {})
                self.assertNotIn("interface", form.fields)


class ISISInterfaceBulkEditFormTests(TestCase):
    """The IS-IS metric is the field operators bulk edit after a drain."""

    def setUp(self):
        location = make_location()
        device = make_device(location)
        self.isis = models.ISISInterface.objects.create(
            interface=make_interface(device, name="ae100"),
            metric=10,
        )

    def _form(self, **data):
        return views.ISISInterfaceUIViewSet.bulk_update_form_class(
            models.ISISInterface,
            {"pk": [str(self.isis.pk)], **data},
        )

    def test_metric_is_accepted(self):
        form = self._form(metric="1000000")
        self.assertTrue(form.is_valid(), form.errors)
        self.assertEqual(form.cleaned_data["metric"], 1_000_000)

    def test_metric_above_the_isis_ceiling_is_rejected(self):
        form = self._form(metric="16777215")
        self.assertFalse(form.is_valid())
        self.assertIn("metric", form.errors)

    def test_zero_metric_is_rejected(self):
        form = self._form(metric="0")
        self.assertFalse(form.is_valid())
        self.assertIn("metric", form.errors)

    def test_omitted_metric_cleans_to_none_so_nothing_is_applied(self):
        form = self._form()
        self.assertTrue(form.is_valid(), form.errors)
        self.assertIsNone(form.cleaned_data["metric"])

    def test_unset_passive_cleans_to_none_rather_than_false(self):
        """A plain BooleanField would force passive=False onto every selected row."""
        form = self._form(metric="500")
        self.assertTrue(form.is_valid(), form.errors)
        self.assertIsNone(form.cleaned_data["passive"])

    def test_passive_can_be_set_explicitly(self):
        form = self._form(passive="True")
        self.assertTrue(form.is_valid(), form.errors)
        self.assertTrue(form.cleaned_data["passive"])

    def test_passive_can_be_cleared_explicitly(self):
        form = self._form(passive="False")
        self.assertTrue(form.is_valid(), form.errors)
        self.assertFalse(form.cleaned_data["passive"])

    def test_level_offers_a_blank_no_change_option(self):
        values = [value for value, _ in self._form().fields["level"].choices]
        self.assertIn(None, values)
        self.assertIn(choices.ISISLevelChoices.LEVEL_2, values)

    def test_hello_authentication_is_nullable(self):
        self.assertIn("hello_authentication", self._form().nullable_fields)


class RSVPInterfaceBulkEditFormTests(TestCase):
    """Percent fields keep their model-level bounds in bulk edit."""

    def setUp(self):
        location = make_location()
        device = make_device(location)
        self.rsvp = models.RSVPInterface.objects.create(
            interface=make_interface(device, name="ae100"),
            subscription_percent=100,
        )

    def _form(self, **data):
        return views.RSVPInterfaceUIViewSet.bulk_update_form_class(
            models.RSVPInterface,
            {"pk": [str(self.rsvp.pk)], **data},
        )

    def test_subscription_percent_within_bounds_is_accepted(self):
        form = self._form(subscription_percent="80")
        self.assertTrue(form.is_valid(), form.errors)
        self.assertEqual(form.cleaned_data["subscription_percent"], 80)

    def test_subscription_percent_above_one_hundred_is_rejected(self):
        form = self._form(subscription_percent="101")
        self.assertFalse(form.is_valid())
        self.assertIn("subscription_percent", form.errors)

    def test_zero_subscription_percent_is_rejected(self):
        form = self._form(subscription_percent="0")
        self.assertFalse(form.is_valid())
        self.assertIn("subscription_percent", form.errors)

    def test_zero_update_threshold_is_allowed(self):
        form = self._form(update_threshold_percent="0")
        self.assertTrue(form.is_valid(), form.errors)
        self.assertEqual(form.cleaned_data["update_threshold_percent"], 0)


class ISISInterfaceBulkEditViewTests(TestCase):
    """Edit Selected reaches the bulk edit job instead of raising TypeError."""

    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_superuser(username="routing-bulk", password="bulk")  # noqa: S106

    def setUp(self):
        location = make_location()
        device = make_device(location)
        self.isis = models.ISISInterface.objects.create(
            interface=make_interface(device, name="ae100"),
            metric=10,
        )
        self.client = Client()
        self.client.force_login(self.user)

    def _post(self, data):
        return self.client.post(reverse("plugins:nautobot_app_routing:isisinterface_bulk_edit"), data)

    def test_edit_selected_renders_the_confirmation_form(self):
        response = self._post({"pk": [str(self.isis.pk)]})
        self.assertEqual(response.status_code, 200)

    def test_applying_enqueues_the_bulk_edit_job(self):
        response = self._post({"pk": [str(self.isis.pk)], "metric": "1000000", "_apply": "Apply"})
        self.assertEqual(response.status_code, 302)
        self.assertIn("/extras/job-results/", response.url)

    def test_invalid_metric_is_reported_instead_of_enqueued(self):
        response = self._post({"pk": [str(self.isis.pk)], "metric": "16777215", "_apply": "Apply"})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Ensure this value is less than or equal to")

    def test_empty_selection_is_reported_instead_of_applied(self):
        response = self._post({"pk": []})
        self.assertEqual(response.status_code, 302)


class BulkEditPermissionTests(TestCase):
    """Bulk edit stays behind object permissions."""

    def setUp(self):
        location = make_location()
        device = make_device(location)
        self.isis = models.ISISInterface.objects.create(
            interface=make_interface(device, name="ae100"),
            metric=10,
        )
        self.user = User.objects.create_user(username="routing-limited", password="limited")  # noqa: S106
        self.client = Client()
        self.client.force_login(self.user)

    def _post(self):
        return self.client.post(
            reverse("plugins:nautobot_app_routing:isisinterface_bulk_edit"),
            {"pk": [str(self.isis.pk)], "metric": "1000000", "_apply": "Apply"},
        )

    def test_user_without_change_permission_is_denied(self):
        response = self._post()
        self.assertIn(response.status_code, (403, 302))
        self.assertNotIn("/extras/job-results/", getattr(response, "url", ""))
        self.isis.refresh_from_db()
        self.assertEqual(self.isis.metric, 10)

    def test_user_with_change_permission_is_allowed(self):
        permission = ObjectPermission.objects.create(name="isis-change", actions=["view", "change"])
        permission.object_types.add(ContentType.objects.get_for_model(models.ISISInterface))
        permission.users.add(self.user)

        response = self._post()
        self.assertEqual(response.status_code, 302)
        self.assertIn("/extras/job-results/", response.url)
