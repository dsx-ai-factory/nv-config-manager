# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Tests for routing plugin forms."""

import json

from django.test import TestCase
from nautobot.extras.models import Status

from nautobot_app_routing import forms, models
from nautobot_app_routing.tests.test_models import make_device, make_interface, make_location

INTERFACE_SCOPED_FORMS = (
    forms.ISISInterfaceForm,
    forms.MPLSInterfaceForm,
    forms.RSVPInterfaceForm,
    forms.EVPNPWServiceForm,
)


class InterfaceScopedFormTests(TestCase):
    """Interface pickers are driven by a device selector."""

    def setUp(self):
        location = make_location()
        self.device = make_device(location)
        self.other_device = make_device(location, name="LHR0A2-BBR-01", model="PTX-other")
        self.interface = make_interface(self.device, name="et-0/0/1")
        self.other_interface = make_interface(self.other_device, name="et-0/0/1")

    def _mpls_data(self, **overrides):
        data = {
            "device": str(self.device.pk),
            "interface": str(self.interface.pk),
            "srlg": "[]",
            "admin_groups": "[]",
        }
        data.update(overrides)
        return data

    def test_device_selector_renders_before_interface(self):
        for form_class in INTERFACE_SCOPED_FORMS:
            with self.subTest(form=form_class.__name__):
                field_names = list(form_class().fields)
                self.assertIn("device", field_names)
                self.assertLess(field_names.index("device"), field_names.index("interface"))

    def test_interface_picker_queries_the_selected_device(self):
        for form_class in INTERFACE_SCOPED_FORMS:
            with self.subTest(form=form_class.__name__):
                attrs = form_class().fields["interface"].widget.attrs
                self.assertEqual(json.loads(attrs["data-query-param-device_id"]), ["$device"])

    def test_editing_preselects_the_owning_device(self):
        mpls = models.MPLSInterface.objects.create(interface=self.interface)
        form = forms.MPLSInterfaceForm(instance=mpls)
        self.assertEqual(form.initial["device"], self.device.pk)

    def test_device_and_interface_on_the_same_device_saves(self):
        form = forms.MPLSInterfaceForm(data=self._mpls_data())
        self.assertTrue(form.is_valid(), form.errors)
        mpls = form.save()
        self.assertEqual(mpls.interface, self.interface)

    def test_interface_from_another_device_is_rejected(self):
        form = forms.MPLSInterfaceForm(data=self._mpls_data(interface=str(self.other_interface.pk)))
        self.assertFalse(form.is_valid())
        self.assertIn("interface", form.errors)

    def test_device_is_optional_so_interface_alone_still_saves(self):
        form = forms.MPLSInterfaceForm(data=self._mpls_data(device=""))
        self.assertTrue(form.is_valid(), form.errors)
        self.assertEqual(form.save().interface, self.interface)


class EVPNPWServiceFormTests(TestCase):
    """The VPWS local attachment interface is device-scoped like the protocol forms."""

    def setUp(self):
        location = make_location()
        self.device = make_device(location)
        self.remote = make_device(location, name="LHR0A2-BBR-02", model="PTX-remote")
        self.interface = make_interface(self.device, name="et-0/0/5")
        self.other_interface = make_interface(self.remote, name="et-0/0/5")
        self.status = Status.objects.get_for_model(models.EVPNPWService).first() or Status.objects.create(
            name="VPWS Active"
        )

    def _data(self, **overrides):
        data = {
            "name": "PW-AMS-LHR-001",
            "local_service_id": 100001,
            "remote_service_id": 100002,
            "device": str(self.device.pk),
            "interface": str(self.interface.pk),
            "remote_pe": str(self.remote.pk),
            "route_distinguisher": "398037:100001",
            "import_target": "398037:100002",
            "export_target": "398037:100001",
            "status": str(self.status.pk),
        }
        data.update(overrides)
        return data

    def test_local_interface_must_belong_to_the_selected_device(self):
        form = forms.EVPNPWServiceForm(data=self._data(interface=str(self.other_interface.pk)))
        self.assertFalse(form.is_valid())
        self.assertIn("interface", form.errors)

    def test_service_saves_with_matching_device_and_interface(self):
        form = forms.EVPNPWServiceForm(data=self._data())
        self.assertTrue(form.is_valid(), form.errors)
        self.assertEqual(form.save().interface, self.interface)
