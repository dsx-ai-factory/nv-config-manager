# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""View sets for the routing plugin API."""

from nautobot.apps.api import NautobotModelViewSet

from nautobot_app_routing import filters, models
from nautobot_app_routing.api import serializers


class AutonomousSystemViewSet(NautobotModelViewSet):
    queryset = models.AutonomousSystem.objects.all()
    serializer_class = serializers.AutonomousSystemSerializer
    filterset_class = filters.AutonomousSystemFilterSet


class BGPRoutingInstanceViewSet(NautobotModelViewSet):
    queryset = models.BGPRoutingInstance.objects.all()
    serializer_class = serializers.BGPRoutingInstanceSerializer
    filterset_class = filters.BGPRoutingInstanceFilterSet


class PeerGroupTemplateViewSet(NautobotModelViewSet):
    queryset = models.PeerGroupTemplate.objects.all()
    serializer_class = serializers.PeerGroupTemplateSerializer
    filterset_class = filters.PeerGroupTemplateFilterSet


class PeerGroupViewSet(NautobotModelViewSet):
    queryset = models.PeerGroup.objects.all()
    serializer_class = serializers.PeerGroupSerializer
    filterset_class = filters.PeerGroupFilterSet


class PeeringViewSet(NautobotModelViewSet):
    queryset = models.Peering.objects.all()
    serializer_class = serializers.PeeringSerializer
    filterset_class = filters.PeeringFilterSet


class PeerEndpointViewSet(NautobotModelViewSet):
    queryset = models.PeerEndpoint.objects.all()
    serializer_class = serializers.PeerEndpointSerializer
    filterset_class = filters.PeerEndpointFilterSet


class AddressFamilyViewSet(NautobotModelViewSet):
    queryset = models.AddressFamily.objects.all()
    serializer_class = serializers.AddressFamilySerializer
    filterset_class = filters.AddressFamilyFilterSet


class ISISRoutingInstanceViewSet(NautobotModelViewSet):
    queryset = models.ISISRoutingInstance.objects.all()
    serializer_class = serializers.ISISRoutingInstanceSerializer
    filterset_class = filters.ISISRoutingInstanceFilterSet


class ISISInterfaceViewSet(NautobotModelViewSet):
    queryset = models.ISISInterface.objects.all()
    serializer_class = serializers.ISISInterfaceSerializer
    filterset_class = filters.ISISInterfaceFilterSet


class MPLSInterfaceViewSet(NautobotModelViewSet):
    queryset = models.MPLSInterface.objects.all()
    serializer_class = serializers.MPLSInterfaceSerializer
    filterset_class = filters.MPLSInterfaceFilterSet


class RSVPInterfaceViewSet(NautobotModelViewSet):
    queryset = models.RSVPInterface.objects.all()
    serializer_class = serializers.RSVPInterfaceSerializer
    filterset_class = filters.RSVPInterfaceFilterSet


class MACsecAssociationViewSet(NautobotModelViewSet):
    queryset = models.MACsecAssociation.objects.all()
    serializer_class = serializers.MACsecAssociationSerializer
    filterset_class = filters.MACsecAssociationFilterSet


class TransportClassViewSet(NautobotModelViewSet):
    queryset = models.TransportClass.objects.all()
    serializer_class = serializers.TransportClassSerializer
    filterset_class = filters.TransportClassFilterSet


class MPLSTemplateViewSet(NautobotModelViewSet):
    queryset = models.MPLSTemplate.objects.all()
    serializer_class = serializers.MPLSTemplateSerializer
    filterset_class = filters.MPLSTemplateFilterSet


class LabelSwitchedPathViewSet(NautobotModelViewSet):
    queryset = models.LabelSwitchedPath.objects.all()
    serializer_class = serializers.LabelSwitchedPathSerializer
    filterset_class = filters.LabelSwitchedPathFilterSet


class EVPNPWServiceViewSet(NautobotModelViewSet):
    queryset = models.EVPNPWService.objects.all()
    serializer_class = serializers.EVPNPWServiceSerializer
    filterset_class = filters.EVPNPWServiceFilterSet


class CommunityDimensionViewSet(NautobotModelViewSet):
    queryset = models.CommunityDimension.objects.all()
    serializer_class = serializers.CommunityDimensionSerializer
    filterset_class = filters.CommunityDimensionFilterSet


class PrefixListViewSet(NautobotModelViewSet):
    queryset = models.PrefixList.objects.all()
    serializer_class = serializers.PrefixListSerializer
    filterset_class = filters.PrefixListFilterSet


class PrefixListEntryViewSet(NautobotModelViewSet):
    queryset = models.PrefixListEntry.objects.all()
    serializer_class = serializers.PrefixListEntrySerializer
    filterset_class = filters.PrefixListEntryFilterSet


class RoutingPolicyViewSet(NautobotModelViewSet):
    queryset = models.RoutingPolicy.objects.all()
    serializer_class = serializers.RoutingPolicySerializer
    filterset_class = filters.RoutingPolicyFilterSet


class RoutingPolicyTermViewSet(NautobotModelViewSet):
    queryset = models.RoutingPolicyTerm.objects.all()
    serializer_class = serializers.RoutingPolicyTermSerializer
    filterset_class = filters.RoutingPolicyTermFilterSet
