# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Serializers for the routing plugin API."""

from nautobot.apps.api import NautobotModelSerializer

from nautobot_app_routing import models


class RoutingModelSerializer(NautobotModelSerializer):
    """Base serializer exposing all model fields."""

    class Meta:
        """Serializer metadata."""

        fields = "__all__"
        abstract = True


class AutonomousSystemSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.AutonomousSystem


class BGPRoutingInstanceSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.BGPRoutingInstance


class PeerGroupTemplateSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.PeerGroupTemplate


class PeerGroupSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.PeerGroup


class PeeringSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.Peering


class PeerEndpointSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.PeerEndpoint


class AddressFamilySerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.AddressFamily


class ISISRoutingInstanceSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.ISISRoutingInstance


class ISISInterfaceSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.ISISInterface


class MPLSInterfaceSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.MPLSInterface


class RSVPInterfaceSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.RSVPInterface


class MACsecAssociationSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.MACsecAssociation


class TransportClassSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.TransportClass


class MPLSTemplateSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.MPLSTemplate


class LabelSwitchedPathSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.LabelSwitchedPath


class EVPNPWServiceSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.EVPNPWService


class CommunityDimensionSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.CommunityDimension


class PrefixListSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.PrefixList


class PrefixListEntrySerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.PrefixListEntry


class RoutingPolicySerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.RoutingPolicy


class RoutingPolicyTermSerializer(RoutingModelSerializer):
    class Meta(RoutingModelSerializer.Meta):
        model = models.RoutingPolicyTerm
