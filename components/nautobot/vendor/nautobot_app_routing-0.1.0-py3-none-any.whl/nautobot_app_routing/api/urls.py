# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""URL patterns for the routing plugin API."""

from nautobot.apps.api import OrderedDefaultRouter

from nautobot_app_routing.api import views

router = OrderedDefaultRouter()
router.register("autonomous-systems", views.AutonomousSystemViewSet)
router.register("bgp-routing-instances", views.BGPRoutingInstanceViewSet)
router.register("peer-group-templates", views.PeerGroupTemplateViewSet)
router.register("peer-groups", views.PeerGroupViewSet)
router.register("peerings", views.PeeringViewSet)
router.register("peer-endpoints", views.PeerEndpointViewSet)
router.register("address-families", views.AddressFamilyViewSet)
router.register("isis-routing-instances", views.ISISRoutingInstanceViewSet)
router.register("isis-interfaces", views.ISISInterfaceViewSet)
router.register("mpls-interfaces", views.MPLSInterfaceViewSet)
router.register("rsvp-interfaces", views.RSVPInterfaceViewSet)
router.register("macsec-associations", views.MACsecAssociationViewSet)
router.register("transport-classes", views.TransportClassViewSet)
router.register("mpls-templates", views.MPLSTemplateViewSet)
router.register("lsps", views.LabelSwitchedPathViewSet)
router.register("evpn-vpws", views.EVPNPWServiceViewSet)
router.register("communities", views.CommunityDimensionViewSet)
router.register("prefix-lists", views.PrefixListViewSet)
router.register("prefix-list-entries", views.PrefixListEntryViewSet)
router.register("routing-policies", views.RoutingPolicyViewSet)
router.register("routing-policy-terms", views.RoutingPolicyTermViewSet)

urlpatterns = router.urls
