# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Forms for the routing plugin."""

from django import forms
from nautobot.apps.forms import (
    BulkEditNullBooleanSelect,
    DynamicModelChoiceField,
    DynamicModelMultipleChoiceField,
    NautobotBulkEditForm,
    NautobotFilterForm,
    NautobotModelForm,
    RoleModelBulkEditFormMixin,
    StatusModelBulkEditFormMixin,
    StatusModelFilterFormMixin,
    TagFilterField,
    TagsBulkEditFormMixin,
    add_blank_choice,
)
from nautobot.circuits.models import Circuit, Provider
from nautobot.core.constants import CHARFIELD_MAX_LENGTH
from nautobot.dcim.models import Device, Interface, Location
from nautobot.extras.models import Secret
from nautobot.ipam.models import VRF, IPAddress

from nautobot_app_routing import models
from nautobot_app_routing.choices import (
    AddressFamilyChoices,
    AFISAFIChoices,
    CommunityKindChoices,
    ISISLevelChoices,
    LSPClassChoices,
    MACsecModeChoices,
    PolicyActionChoices,
    PrefixMatchChoices,
    RSVPProtectionChoices,
)


class InterfaceScopedModelForm(NautobotModelForm):
    """Base form for routing intent attached to a single Interface."""

    device = DynamicModelChoiceField(queryset=Device.objects.all(), required=False)
    interface = DynamicModelChoiceField(
        queryset=Interface.objects.all(),
        query_params={"device_id": "$device"},
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.present_in_database:
            self.initial["device"] = self.instance.interface.device_id

    def clean(self):
        # Nautobot's form mixins do not return cleaned_data from clean().
        super().clean()
        device = self.cleaned_data.get("device")
        interface = self.cleaned_data.get("interface")
        if device and interface and interface.device_id != device.pk:
            self.add_error("interface", f"{interface} does not belong to {device}.")
        return self.cleaned_data


class AutonomousSystemForm(NautobotModelForm):
    """Form for AutonomousSystem."""

    provider = DynamicModelChoiceField(queryset=Provider.objects.all(), required=False)

    class Meta:
        model = models.AutonomousSystem
        fields = ["asn", "description", "provider", "status", "tags"]


class AutonomousSystemFilterForm(NautobotFilterForm, StatusModelFilterFormMixin):
    """Filter form for AutonomousSystem."""

    model = models.AutonomousSystem
    field_order = ["q", "provider", "status", "tags"]
    provider = DynamicModelChoiceField(queryset=Provider.objects.all(), required=False)
    tag = TagFilterField(model)


class AutonomousSystemBulkEditForm(TagsBulkEditFormMixin, StatusModelBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for AutonomousSystem."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.AutonomousSystem.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    description = forms.CharField(max_length=200, required=False)
    provider = DynamicModelChoiceField(queryset=Provider.objects.all(), required=False)

    class Meta:
        nullable_fields = ["description", "provider"]


class BGPRoutingInstanceForm(NautobotModelForm):
    """Form for BGPRoutingInstance."""

    device = DynamicModelChoiceField(queryset=Device.objects.all())
    router_id = DynamicModelChoiceField(queryset=IPAddress.objects.all(), required=False)
    autonomous_system = DynamicModelChoiceField(queryset=models.AutonomousSystem.objects.all())

    class Meta:
        model = models.BGPRoutingInstance
        fields = ["device", "router_id", "autonomous_system", "description", "status", "tags"]


class BGPRoutingInstanceFilterForm(NautobotFilterForm, StatusModelFilterFormMixin):
    """Filter form for BGPRoutingInstance."""

    model = models.BGPRoutingInstance
    field_order = ["q", "device", "autonomous_system", "status", "tags"]
    device = DynamicModelChoiceField(queryset=Device.objects.all(), required=False)
    autonomous_system = DynamicModelChoiceField(queryset=models.AutonomousSystem.objects.all(), required=False)
    tag = TagFilterField(model)


class BGPRoutingInstanceBulkEditForm(TagsBulkEditFormMixin, StatusModelBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for BGPRoutingInstance."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.BGPRoutingInstance.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    autonomous_system = DynamicModelChoiceField(queryset=models.AutonomousSystem.objects.all(), required=False)
    router_id = DynamicModelChoiceField(queryset=IPAddress.objects.all(), required=False)
    description = forms.CharField(max_length=200, required=False)

    class Meta:
        nullable_fields = ["router_id", "description"]


class PeerGroupTemplateForm(NautobotModelForm):
    """Form for PeerGroupTemplate."""

    autonomous_system = DynamicModelChoiceField(
        queryset=models.AutonomousSystem.objects.all(),
        required=False,
    )
    secret = DynamicModelChoiceField(queryset=Secret.objects.all(), required=False)

    class Meta:
        model = models.PeerGroupTemplate
        fields = [
            "name",
            "enabled",
            "role",
            "description",
            "autonomous_system",
            "secret",
            "extra_attributes",
            "tags",
        ]


class PeerGroupTemplateFilterForm(NautobotFilterForm):
    """Filter form for PeerGroupTemplate."""

    model = models.PeerGroupTemplate
    field_order = ["q", "autonomous_system", "role", "enabled", "tags"]
    autonomous_system = DynamicModelChoiceField(
        queryset=models.AutonomousSystem.objects.all(),
        required=False,
    )
    tag = TagFilterField(model)


class PeerGroupTemplateBulkEditForm(TagsBulkEditFormMixin, RoleModelBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for PeerGroupTemplate."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.PeerGroupTemplate.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    enabled = forms.NullBooleanField(required=False, widget=BulkEditNullBooleanSelect())
    description = forms.CharField(max_length=200, required=False)
    autonomous_system = DynamicModelChoiceField(queryset=models.AutonomousSystem.objects.all(), required=False)
    secret = DynamicModelChoiceField(queryset=Secret.objects.all(), required=False)

    class Meta:
        nullable_fields = ["role", "description", "autonomous_system", "secret"]


class PeerGroupForm(NautobotModelForm):
    """Form for PeerGroup."""

    routing_instance = DynamicModelChoiceField(queryset=models.BGPRoutingInstance.objects.all())
    vrf = DynamicModelChoiceField(queryset=VRF.objects.all(), required=False)
    autonomous_system = DynamicModelChoiceField(queryset=models.AutonomousSystem.objects.all(), required=False)
    peergroup_template = DynamicModelChoiceField(queryset=models.PeerGroupTemplate.objects.all(), required=False)
    source_ip = DynamicModelChoiceField(queryset=IPAddress.objects.all(), required=False)
    source_interface = DynamicModelChoiceField(queryset=Interface.objects.all(), required=False)

    class Meta:
        model = models.PeerGroup
        fields = [
            "name",
            "routing_instance",
            "peergroup_template",
            "vrf",
            "description",
            "enabled",
            "autonomous_system",
            "source_ip",
            "source_interface",
            "role",
            "tags",
        ]


class PeerGroupFilterForm(NautobotFilterForm):
    """Filter form for PeerGroup."""

    model = models.PeerGroup
    field_order = ["q", "routing_instance", "tags"]
    routing_instance = DynamicModelChoiceField(queryset=models.BGPRoutingInstance.objects.all(), required=False)
    tag = TagFilterField(model)


class PeerGroupBulkEditForm(TagsBulkEditFormMixin, RoleModelBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for PeerGroup."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.PeerGroup.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    peergroup_template = DynamicModelChoiceField(queryset=models.PeerGroupTemplate.objects.all(), required=False)
    vrf = DynamicModelChoiceField(queryset=VRF.objects.all(), required=False)
    autonomous_system = DynamicModelChoiceField(queryset=models.AutonomousSystem.objects.all(), required=False)
    source_ip = DynamicModelChoiceField(queryset=IPAddress.objects.all(), required=False)
    source_interface = DynamicModelChoiceField(queryset=Interface.objects.all(), required=False)
    secret = DynamicModelChoiceField(queryset=Secret.objects.all(), required=False)
    enabled = forms.NullBooleanField(required=False, widget=BulkEditNullBooleanSelect())
    description = forms.CharField(max_length=200, required=False)

    class Meta:
        nullable_fields = [
            "peergroup_template",
            "vrf",
            "autonomous_system",
            "source_ip",
            "source_interface",
            "secret",
            "role",
            "description",
        ]


class PeeringForm(NautobotModelForm):
    """Form for Peering."""

    class Meta:
        model = models.Peering
        fields = ["status", "tags"]


class PeeringFilterForm(NautobotFilterForm, StatusModelFilterFormMixin):
    """Filter form for Peering."""

    model = models.Peering
    field_order = ["status", "tags"]
    tag = TagFilterField(model)


class PeeringBulkEditForm(TagsBulkEditFormMixin, StatusModelBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for Peering."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.Peering.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )

    class Meta:
        nullable_fields = []


class PeerEndpointForm(NautobotModelForm):
    """Form for PeerEndpoint."""

    routing_instance = DynamicModelChoiceField(
        queryset=models.BGPRoutingInstance.objects.all(),
        required=False,
    )
    autonomous_system = DynamicModelChoiceField(
        queryset=models.AutonomousSystem.objects.all(),
        required=False,
    )
    peer = DynamicModelChoiceField(queryset=models.PeerEndpoint.objects.all(), required=False)
    peering = DynamicModelChoiceField(queryset=models.Peering.objects.all())
    peer_group = DynamicModelChoiceField(queryset=models.PeerGroup.objects.all(), required=False)
    source_ip = DynamicModelChoiceField(queryset=IPAddress.objects.all(), required=False)
    source_interface = DynamicModelChoiceField(queryset=Interface.objects.all(), required=False)
    secret = DynamicModelChoiceField(queryset=Secret.objects.all(), required=False)

    class Meta:
        model = models.PeerEndpoint
        fields = [
            "peering",
            "peer",
            "routing_instance",
            "peer_group",
            "autonomous_system",
            "source_ip",
            "source_interface",
            "role",
            "description",
            "enabled",
            "secret",
            "extra_attributes",
            "tags",
        ]


class PeerEndpointFilterForm(NautobotFilterForm):
    """Filter form for PeerEndpoint."""

    model = models.PeerEndpoint
    field_order = ["q", "peering", "routing_instance", "peer_group", "enabled", "tags"]
    peering = DynamicModelChoiceField(queryset=models.Peering.objects.all(), required=False)
    routing_instance = DynamicModelChoiceField(
        queryset=models.BGPRoutingInstance.objects.all(),
        required=False,
    )
    peer_group = DynamicModelChoiceField(queryset=models.PeerGroup.objects.all(), required=False)
    tag = TagFilterField(model)


class PeerEndpointBulkEditForm(TagsBulkEditFormMixin, RoleModelBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for PeerEndpoint."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.PeerEndpoint.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    routing_instance = DynamicModelChoiceField(queryset=models.BGPRoutingInstance.objects.all(), required=False)
    peer_group = DynamicModelChoiceField(queryset=models.PeerGroup.objects.all(), required=False)
    autonomous_system = DynamicModelChoiceField(queryset=models.AutonomousSystem.objects.all(), required=False)
    source_ip = DynamicModelChoiceField(queryset=IPAddress.objects.all(), required=False)
    source_interface = DynamicModelChoiceField(queryset=Interface.objects.all(), required=False)
    secret = DynamicModelChoiceField(queryset=Secret.objects.all(), required=False)
    enabled = forms.NullBooleanField(required=False, widget=BulkEditNullBooleanSelect())
    description = forms.CharField(max_length=200, required=False)

    class Meta:
        nullable_fields = [
            "routing_instance",
            "peer_group",
            "autonomous_system",
            "source_ip",
            "source_interface",
            "secret",
            "role",
            "description",
        ]


class AddressFamilyForm(NautobotModelForm):
    """Form for AddressFamily."""

    routing_instance = DynamicModelChoiceField(queryset=models.BGPRoutingInstance.objects.all())
    import_policy = DynamicModelChoiceField(
        queryset=models.RoutingPolicy.objects.all(),
        required=False,
    )
    export_policy = DynamicModelChoiceField(
        queryset=models.RoutingPolicy.objects.all(),
        required=False,
    )

    class Meta:
        model = models.AddressFamily
        fields = [
            "routing_instance",
            "afi_safi",
            "import_policy",
            "export_policy",
            "extra_attributes",
            "tags",
        ]


class AddressFamilyFilterForm(NautobotFilterForm):
    """Filter form for AddressFamily."""

    model = models.AddressFamily
    field_order = ["routing_instance", "afi_safi", "tags"]
    routing_instance = DynamicModelChoiceField(
        queryset=models.BGPRoutingInstance.objects.all(),
        required=False,
    )
    tag = TagFilterField(model)


class AddressFamilyBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for AddressFamily."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.AddressFamily.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    afi_safi = forms.ChoiceField(choices=add_blank_choice(AFISAFIChoices), required=False)
    import_policy = DynamicModelChoiceField(queryset=models.RoutingPolicy.objects.all(), required=False)
    export_policy = DynamicModelChoiceField(queryset=models.RoutingPolicy.objects.all(), required=False)

    class Meta:
        nullable_fields = ["import_policy", "export_policy"]


class RoutingPolicyForm(NautobotModelForm):
    """Form for RoutingPolicy."""

    class Meta:
        model = models.RoutingPolicy
        fields = ["name", "description", "default_action", "tags"]


class RoutingPolicyFilterForm(NautobotFilterForm):
    """Filter form for RoutingPolicy."""

    model = models.RoutingPolicy
    field_order = ["q", "tags"]
    tag = TagFilterField(model)


class RoutingPolicyBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for RoutingPolicy."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.RoutingPolicy.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    description = forms.CharField(max_length=CHARFIELD_MAX_LENGTH, required=False)
    default_action = forms.ChoiceField(choices=add_blank_choice(PolicyActionChoices), required=False)

    class Meta:
        nullable_fields = ["description"]


class RoutingPolicyTermForm(NautobotModelForm):
    """Form for RoutingPolicyTerm."""

    policy = DynamicModelChoiceField(queryset=models.RoutingPolicy.objects.all())

    class Meta:
        model = models.RoutingPolicyTerm
        fields = ["policy", "name", "sequence", "from_policy", "then_action", "tags"]


class RoutingPolicyTermFilterForm(NautobotFilterForm):
    """Filter form for RoutingPolicyTerm."""

    model = models.RoutingPolicyTerm
    field_order = ["q", "policy", "tags"]
    policy = DynamicModelChoiceField(queryset=models.RoutingPolicy.objects.all(), required=False)
    tag = TagFilterField(model)


class RoutingPolicyTermBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for RoutingPolicyTerm."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.RoutingPolicyTerm.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    policy = DynamicModelChoiceField(queryset=models.RoutingPolicy.objects.all(), required=False)
    sequence = forms.IntegerField(min_value=0, required=False)
    from_policy = forms.CharField(required=False)
    then_action = forms.ChoiceField(choices=add_blank_choice(PolicyActionChoices), required=False)

    class Meta:
        nullable_fields = ["from_policy"]


class PrefixListForm(NautobotModelForm):
    """Form for PrefixList."""

    class Meta:
        model = models.PrefixList
        fields = ["name", "description", "address_family", "tags"]


class PrefixListFilterForm(NautobotFilterForm):
    """Filter form for PrefixList."""

    model = models.PrefixList
    field_order = ["q", "address_family", "tags"]
    address_family = forms.MultipleChoiceField(choices=AddressFamilyChoices, required=False)
    tag = TagFilterField(model)


class PrefixListBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for PrefixList."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.PrefixList.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    description = forms.CharField(max_length=CHARFIELD_MAX_LENGTH, required=False)
    address_family = forms.ChoiceField(choices=add_blank_choice(AddressFamilyChoices), required=False)

    class Meta:
        nullable_fields = ["description"]


class PrefixListEntryForm(NautobotModelForm):
    """Form for PrefixListEntry."""

    prefix_list = DynamicModelChoiceField(queryset=models.PrefixList.objects.all())

    class Meta:
        model = models.PrefixListEntry
        fields = ["prefix_list", "prefix", "match", "tags"]


class PrefixListEntryFilterForm(NautobotFilterForm):
    """Filter form for PrefixListEntry."""

    model = models.PrefixListEntry
    field_order = ["q", "prefix_list", "tags"]
    prefix_list = DynamicModelChoiceField(queryset=models.PrefixList.objects.all(), required=False)
    tag = TagFilterField(model)


class PrefixListEntryBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for PrefixListEntry."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.PrefixListEntry.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    prefix_list = DynamicModelChoiceField(queryset=models.PrefixList.objects.all(), required=False)
    match = forms.ChoiceField(choices=add_blank_choice(PrefixMatchChoices), required=False)

    class Meta:
        nullable_fields = []


class CommunityDimensionForm(NautobotModelForm):
    """Form for CommunityDimension."""

    parent = DynamicModelChoiceField(queryset=models.CommunityDimension.objects.all(), required=False)
    location = DynamicModelChoiceField(queryset=Location.objects.all(), required=False)

    class Meta:
        model = models.CommunityDimension
        fields = ["kind", "code", "community_id", "parent", "location", "description", "tags"]


class CommunityDimensionFilterForm(NautobotFilterForm):
    """Filter form for CommunityDimension."""

    model = models.CommunityDimension
    field_order = ["q", "kind", "parent", "tags"]
    kind = forms.MultipleChoiceField(choices=CommunityKindChoices, required=False)
    parent = DynamicModelChoiceField(queryset=models.CommunityDimension.objects.all(), required=False)
    tag = TagFilterField(model)


class CommunityDimensionBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for CommunityDimension."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.CommunityDimension.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    kind = forms.ChoiceField(choices=add_blank_choice(CommunityKindChoices), required=False)
    parent = DynamicModelChoiceField(queryset=models.CommunityDimension.objects.all(), required=False)
    location = DynamicModelChoiceField(queryset=Location.objects.all(), required=False)
    description = forms.CharField(max_length=CHARFIELD_MAX_LENGTH, required=False)

    class Meta:
        nullable_fields = ["parent", "location", "description"]


class ISISRoutingInstanceForm(NautobotModelForm):
    """Form for ISISRoutingInstance."""

    device = DynamicModelChoiceField(queryset=Device.objects.all())
    protocol_authentication = DynamicModelChoiceField(queryset=Secret.objects.all(), required=False)

    class Meta:
        model = models.ISISRoutingInstance
        fields = ["device", "net", "protocol_authentication", "tags"]


class ISISRoutingInstanceFilterForm(NautobotFilterForm):
    """Filter form for ISISRoutingInstance."""

    model = models.ISISRoutingInstance
    field_order = ["q", "device", "tags"]
    device = DynamicModelChoiceField(queryset=Device.objects.all(), required=False)
    tag = TagFilterField(model)


class ISISRoutingInstanceBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for ISISRoutingInstance."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.ISISRoutingInstance.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    protocol_authentication = DynamicModelChoiceField(queryset=Secret.objects.all(), required=False)

    class Meta:
        nullable_fields = ["protocol_authentication"]


class ISISInterfaceForm(InterfaceScopedModelForm):
    """Form for ISISInterface."""

    hello_authentication = DynamicModelChoiceField(queryset=Secret.objects.all(), required=False)

    class Meta:
        model = models.ISISInterface
        fields = ["device", "interface", "metric", "level", "passive", "hello_authentication", "tags"]


class ISISInterfaceFilterForm(NautobotFilterForm):
    """Filter form for ISISInterface."""

    model = models.ISISInterface
    field_order = ["q", "device", "interface", "tags"]
    device = DynamicModelChoiceField(queryset=Device.objects.all(), required=False)
    interface = DynamicModelChoiceField(queryset=Interface.objects.all(), required=False)
    tag = TagFilterField(model)


class ISISInterfaceBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for ISISInterface."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.ISISInterface.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    metric = forms.IntegerField(min_value=1, max_value=16_777_214, required=False)
    level = forms.ChoiceField(choices=add_blank_choice(ISISLevelChoices), required=False)
    passive = forms.NullBooleanField(required=False, widget=BulkEditNullBooleanSelect())
    hello_authentication = DynamicModelChoiceField(queryset=Secret.objects.all(), required=False)

    class Meta:
        nullable_fields = ["hello_authentication"]


class MPLSInterfaceForm(InterfaceScopedModelForm):
    """Form for MPLSInterface."""

    class Meta:
        model = models.MPLSInterface
        fields = ["device", "interface", "srlg", "admin_groups", "tags"]


class MPLSInterfaceFilterForm(NautobotFilterForm):
    """Filter form for MPLSInterface."""

    model = models.MPLSInterface
    field_order = ["q", "device", "interface", "tags"]
    device = DynamicModelChoiceField(queryset=Device.objects.all(), required=False)
    interface = DynamicModelChoiceField(queryset=Interface.objects.all(), required=False)
    tag = TagFilterField(model)


class MPLSInterfaceBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for MPLSInterface."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.MPLSInterface.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    srlg = forms.JSONField(required=False, label="SRLGs")
    admin_groups = forms.JSONField(required=False, label="Admin Groups")

    class Meta:
        nullable_fields = []


class RSVPInterfaceForm(InterfaceScopedModelForm):
    """Form for RSVPInterface."""

    class Meta:
        model = models.RSVPInterface
        fields = [
            "device",
            "interface",
            "subscription_percent",
            "update_threshold_percent",
            "link_protection",
            "tags",
        ]


class RSVPInterfaceFilterForm(NautobotFilterForm):
    """Filter form for RSVPInterface."""

    model = models.RSVPInterface
    field_order = ["q", "device", "interface", "tags"]
    device = DynamicModelChoiceField(queryset=Device.objects.all(), required=False)
    interface = DynamicModelChoiceField(queryset=Interface.objects.all(), required=False)
    tag = TagFilterField(model)


class RSVPInterfaceBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for RSVPInterface."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.RSVPInterface.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    subscription_percent = forms.IntegerField(min_value=1, max_value=100, required=False)
    update_threshold_percent = forms.IntegerField(min_value=0, max_value=100, required=False)
    link_protection = forms.ChoiceField(choices=add_blank_choice(RSVPProtectionChoices), required=False)

    class Meta:
        nullable_fields = []


class MACsecAssociationForm(NautobotModelForm):
    """Form for MACsecAssociation."""

    secret = DynamicModelChoiceField(queryset=Secret.objects.all(), required=False)
    interfaces = DynamicModelMultipleChoiceField(queryset=Interface.objects.all(), required=False)

    class Meta:
        model = models.MACsecAssociation
        fields = ["name", "mode", "include_sci", "secret", "interfaces", "tags"]


class MACsecAssociationFilterForm(NautobotFilterForm):
    """Filter form for MACsecAssociation."""

    model = models.MACsecAssociation
    field_order = ["q", "tags"]
    tag = TagFilterField(model)


class MACsecAssociationBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for MACsecAssociation."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.MACsecAssociation.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    mode = forms.ChoiceField(choices=add_blank_choice(MACsecModeChoices), required=False)
    include_sci = forms.NullBooleanField(required=False, widget=BulkEditNullBooleanSelect(), label="Include SCI")
    secret = DynamicModelChoiceField(queryset=Secret.objects.all(), required=False)
    add_interfaces = DynamicModelMultipleChoiceField(queryset=Interface.objects.all(), required=False)
    remove_interfaces = DynamicModelMultipleChoiceField(queryset=Interface.objects.all(), required=False)

    class Meta:
        nullable_fields = ["secret", "interfaces"]


class TransportClassForm(NautobotModelForm):
    """Form for TransportClass."""

    class Meta:
        model = models.TransportClass
        fields = ["name", "lsp_class", "color", "status", "tags"]


class TransportClassFilterForm(NautobotFilterForm, StatusModelFilterFormMixin):
    """Filter form for TransportClass."""

    model = models.TransportClass
    field_order = ["q", "lsp_class", "status", "tags"]
    lsp_class = forms.MultipleChoiceField(choices=LSPClassChoices, required=False)
    tag = TagFilterField(model)


class TransportClassBulkEditForm(TagsBulkEditFormMixin, StatusModelBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for TransportClass."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.TransportClass.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    lsp_class = forms.ChoiceField(choices=add_blank_choice(LSPClassChoices), required=False, label="LSP Class")
    color = forms.IntegerField(min_value=0, required=False)

    class Meta:
        nullable_fields = ["color"]


class MPLSTemplateForm(NautobotModelForm):
    """Form for MPLSTemplate."""

    transport_class = DynamicModelChoiceField(queryset=models.TransportClass.objects.all())

    class Meta:
        model = models.MPLSTemplate
        fields = ["name", "description", "transport_class", "tags"]


class MPLSTemplateFilterForm(NautobotFilterForm):
    """Filter form for MPLSTemplate."""

    model = models.MPLSTemplate
    field_order = ["q", "transport_class", "tags"]
    transport_class = DynamicModelChoiceField(queryset=models.TransportClass.objects.all(), required=False)
    tag = TagFilterField(model)


class MPLSTemplateBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for MPLSTemplate."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.MPLSTemplate.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    description = forms.CharField(max_length=CHARFIELD_MAX_LENGTH, required=False)
    transport_class = DynamicModelChoiceField(queryset=models.TransportClass.objects.all(), required=False)

    class Meta:
        nullable_fields = ["description"]


class LabelSwitchedPathForm(NautobotModelForm):
    """Form for LabelSwitchedPath."""

    device = DynamicModelChoiceField(queryset=Device.objects.all())
    template = DynamicModelChoiceField(queryset=models.MPLSTemplate.objects.all(), required=False)

    class Meta:
        model = models.LabelSwitchedPath
        fields = ["name", "device", "template", "to_address", "status", "tags"]


class LabelSwitchedPathFilterForm(NautobotFilterForm, StatusModelFilterFormMixin):
    """Filter form for LabelSwitchedPath."""

    model = models.LabelSwitchedPath
    field_order = ["q", "device", "template", "status", "tags"]
    device = DynamicModelChoiceField(queryset=Device.objects.all(), required=False)
    template = DynamicModelChoiceField(queryset=models.MPLSTemplate.objects.all(), required=False)
    tag = TagFilterField(model)


class LabelSwitchedPathBulkEditForm(TagsBulkEditFormMixin, StatusModelBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for LabelSwitchedPath."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.LabelSwitchedPath.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    template = DynamicModelChoiceField(queryset=models.MPLSTemplate.objects.all(), required=False)
    to_address = forms.GenericIPAddressField(required=False, label="To Address")

    class Meta:
        nullable_fields = ["template", "to_address"]


class EVPNPWServiceForm(InterfaceScopedModelForm):
    """Form for EVPNPWService."""

    remote_pe = DynamicModelChoiceField(queryset=Device.objects.all(), required=False)
    circuit = DynamicModelChoiceField(queryset=Circuit.objects.all(), required=False)
    transport_class = DynamicModelChoiceField(queryset=models.TransportClass.objects.all(), required=False)

    class Meta:
        model = models.EVPNPWService
        fields = [
            "name",
            "local_service_id",
            "remote_service_id",
            "device",
            "interface",
            "remote_pe",
            "remote_pe_address",
            "circuit",
            "route_distinguisher",
            "import_target",
            "export_target",
            "transport_class",
            "mtu",
            "status",
            "tags",
        ]


class EVPNPWServiceFilterForm(NautobotFilterForm, StatusModelFilterFormMixin):
    """Filter form for EVPNPWService."""

    model = models.EVPNPWService
    field_order = ["q", "interface", "remote_pe", "status", "tags"]
    interface = DynamicModelChoiceField(queryset=Interface.objects.all(), required=False)
    remote_pe = DynamicModelChoiceField(queryset=Device.objects.all(), required=False)
    tag = TagFilterField(model)


class EVPNPWServiceBulkEditForm(TagsBulkEditFormMixin, StatusModelBulkEditFormMixin, NautobotBulkEditForm):
    """Bulk edit form for EVPNPWService."""

    pk = forms.ModelMultipleChoiceField(
        queryset=models.EVPNPWService.objects.all(),
        widget=forms.MultipleHiddenInput(),
    )
    remote_pe = DynamicModelChoiceField(queryset=Device.objects.all(), required=False, label="Remote PE")
    remote_pe_address = forms.GenericIPAddressField(required=False, label="Remote PE Address")
    circuit = DynamicModelChoiceField(queryset=Circuit.objects.all(), required=False)
    route_distinguisher = forms.CharField(
        max_length=CHARFIELD_MAX_LENGTH,
        required=False,
        label="Route Distinguisher",
    )
    import_target = forms.CharField(max_length=CHARFIELD_MAX_LENGTH, required=False, label="Import Target")
    export_target = forms.CharField(max_length=CHARFIELD_MAX_LENGTH, required=False, label="Export Target")
    transport_class = DynamicModelChoiceField(
        queryset=models.TransportClass.objects.all(),
        required=False,
        label="Transport Class",
    )
    mtu = forms.IntegerField(min_value=0, required=False, label="MTU")

    class Meta:
        nullable_fields = ["remote_pe", "remote_pe_address", "circuit", "transport_class", "mtu"]
