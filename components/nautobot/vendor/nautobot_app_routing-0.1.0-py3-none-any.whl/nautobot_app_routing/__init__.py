# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""App declaration for nautobot_app_routing."""

from nautobot.apps import NautobotAppConfig

__version__ = "0.1.0"


class NautobotAppRoutingConfig(NautobotAppConfig):
    """App configuration for the routing plugin."""

    name = "nautobot_app_routing"
    verbose_name = "Routing"
    version = __version__
    author = "Backbone Engineering"
    description = "Backbone link inventory, vendored BGP, routing policy, and MPLS service models."
    base_url = "routing"
    required_settings = []
    min_version = "2.4.0"
    max_version = "2.9999"
    default_settings = {}
    caching_config = {}

    def ready(self):
        """Register signal handlers."""
        from django.db.models.signals import post_migrate

        from nautobot_app_routing.signals import post_migrate_create_defaults

        post_migrate.connect(post_migrate_create_defaults, sender=self)
        super().ready()


config = NautobotAppRoutingConfig
