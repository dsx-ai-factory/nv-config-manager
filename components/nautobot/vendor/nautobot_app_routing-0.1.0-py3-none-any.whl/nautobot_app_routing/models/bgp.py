# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""BGP models vendored from nautobot-app-bgp-models (demo subset)."""

from django.core.exceptions import ValidationError
from django.db import models
from nautobot.apps.models import extras_features
from nautobot.circuits.models import Provider
from nautobot.core.models.fields import TagsField
from nautobot.dcim.fields import ASNField
from nautobot.extras.models import RoleField, StatusField
from netutils.asn import int_to_asdot

from nautobot_app_routing.choices import AFISAFIChoices
from nautobot_app_routing.models.base import RoutingOrganizationalModel, RoutingPrimaryModel
from nautobot_app_routing.models.bgp_mixins import BGPExtraAttributesMixin, InheritanceMixin


@extras_features("custom_fields", "relationships", "statuses")
class AutonomousSystem(RoutingPrimaryModel):
    """Autonomous System information."""

    asn = ASNField(unique=True, verbose_name="ASN")
    description = models.CharField(max_length=200, blank=True)
    provider = models.ForeignKey(
        to=Provider,
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="routing_autonomous_systems",
    )
    status = StatusField(null=True, related_name="routing_autonomous_systems")
    tags = TagsField(related_name="routing_autonomous_systems")

    class Meta:
        ordering = ["asn"]
        verbose_name = "Autonomous System"
        verbose_name_plural = "Autonomous Systems"

    def __str__(self):
        return f"AS {self.asn}"

    @property
    def asn_asdot(self):
        return int_to_asdot(self.asn)


@extras_features("custom_fields", "relationships", "statuses")
class BGPRoutingInstance(RoutingPrimaryModel, BGPExtraAttributesMixin):
    """BGP instance definition."""

    description = models.CharField(max_length=200, blank=True)
    device = models.ForeignKey(
        to="dcim.Device",
        on_delete=models.PROTECT,
        related_name="routing_bgp_routing_instances",
    )
    router_id = models.ForeignKey(
        to="ipam.IPAddress",
        blank=True,
        null=True,
        on_delete=models.PROTECT,
        related_name="routing_bgp_routing_instances",
        verbose_name="Router ID",
    )
    autonomous_system = models.ForeignKey(
        to=AutonomousSystem,
        on_delete=models.PROTECT,
        verbose_name="Autonomous System",
    )
    status = StatusField(null=True, related_name="routing_bgp_routing_instances")
    tags = TagsField(related_name="routing_bgp_routing_instances")

    class Meta:
        verbose_name = "BGP Routing Instance"
        verbose_name_plural = "BGP Routing Instances"
        unique_together = [("device", "autonomous_system")]

    def __str__(self):
        return f"{self.device} - {self.autonomous_system}"


@extras_features("custom_fields", "relationships")
class PeerGroupTemplate(RoutingPrimaryModel, BGPExtraAttributesMixin):
    """Peer group template."""

    name = models.CharField(max_length=100, unique=True)
    enabled = models.BooleanField(default=True)
    role = RoleField(blank=True, null=True, related_name="routing_bgp_peer_group_templates")
    description = models.CharField(max_length=200, blank=True)
    tags = TagsField(related_name="routing_bgp_peer_group_templates")
    autonomous_system = models.ForeignKey(
        to=AutonomousSystem,
        blank=True,
        null=True,
        related_name="peer_group_templates",
        on_delete=models.PROTECT,
        verbose_name="Autonomous System",
    )
    secret = models.ForeignKey(
        to="extras.Secret",
        on_delete=models.PROTECT,
        related_name="routing_peer_group_templates",
        blank=True,
        null=True,
    )

    class Meta:
        verbose_name = "BGP Peer Group Template"
        verbose_name_plural = "BGP Peer Group Templates"

    def __str__(self):
        return self.name


@extras_features("custom_fields", "relationships")
class PeerGroup(RoutingPrimaryModel, InheritanceMixin, BGPExtraAttributesMixin):
    """BGP peer group."""

    extra_attributes_inheritance = ["peergroup_template", "routing_instance"]
    property_inheritance = {
        "autonomous_system": ["peergroup_template", "routing_instance"],
        "description": ["peergroup_template"],
        "enabled": ["peergroup_template"],
        "role": ["peergroup_template"],
    }

    name = models.CharField(max_length=100)
    peergroup_template = models.ForeignKey(
        to=PeerGroupTemplate,
        on_delete=models.PROTECT,
        related_name="peer_groups",
        blank=True,
        null=True,
        verbose_name="Peer Group Template",
    )
    role = RoleField(blank=True, null=True, related_name="routing_bgp_peer_groups")
    tags = TagsField(related_name="routing_bgp_peer_groups")
    vrf = models.ForeignKey(
        to="ipam.VRF",
        related_name="routing_peer_groups",
        blank=True,
        null=True,
        on_delete=models.PROTECT,
        verbose_name="VRF",
    )
    description = models.CharField(max_length=200, blank=True)
    enabled = models.BooleanField(default=True)
    routing_instance = models.ForeignKey(
        to=BGPRoutingInstance,
        on_delete=models.CASCADE,
        related_name="peer_groups",
        verbose_name="Routing Instance",
    )
    autonomous_system = models.ForeignKey(
        to=AutonomousSystem,
        blank=True,
        null=True,
        related_name="peer_groups",
        on_delete=models.PROTECT,
        verbose_name="Autonomous System",
    )
    source_ip = models.ForeignKey(
        to="ipam.IPAddress",
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="routing_bgp_peer_groups",
        verbose_name="Source IP",
    )
    source_interface = models.ForeignKey(
        to="dcim.Interface",
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="routing_bgp_peer_groups",
        verbose_name="Source Interface",
    )
    secret = models.ForeignKey(
        to="extras.Secret",
        on_delete=models.PROTECT,
        related_name="routing_bgp_peer_groups",
        blank=True,
        null=True,
    )

    class Meta:
        unique_together = [("name", "routing_instance", "vrf")]
        verbose_name = "BGP Peer Group"
        verbose_name_plural = "BGP Peer Groups"
        ordering = ["name"]

    def __str__(self):
        if self.vrf:
            return f"{self.name} (VRF {self.vrf}) - {self.routing_instance.device}"
        return f"{self.name} - {self.routing_instance.device}"


@extras_features("custom_fields", "relationships", "statuses")
class Peering(RoutingOrganizationalModel):
    """Linkage between two peer endpoints."""

    status = StatusField(null=True, related_name="routing_bgp_peerings")
    tags = TagsField(related_name="routing_bgp_peerings")

    class Meta:
        verbose_name = "BGP Peering"
        verbose_name_plural = "BGP Peerings"

    def __str__(self):
        return str(self.pk)


@extras_features("custom_fields", "relationships")
class PeerEndpoint(RoutingPrimaryModel, InheritanceMixin, BGPExtraAttributesMixin):
    """BGP information about a single peering endpoint."""

    extra_attributes_inheritance = ["peer_group", "peer_group.peergroup_template", "routing_instance"]
    property_inheritance = {
        "autonomous_system": ["peer_group", "peer_group.peergroup_template", "routing_instance"],
        "description": ["peer_group", "peer_group.peergroup_template"],
        "enabled": ["peer_group", "peer_group.peergroup_template"],
        "source_ip": ["peer_group"],
        "source_interface": ["peer_group"],
        "role": ["peer_group.role", "peer_group.peergroup_template.role"],
    }

    description = models.CharField(max_length=200, blank=True)
    role = RoleField(blank=True, null=True, related_name="routing_bgp_peer_endpoints")
    enabled = models.BooleanField(default=True)
    tags = TagsField(related_name="routing_bgp_peer_endpoints")
    routing_instance = models.ForeignKey(
        to=BGPRoutingInstance,
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name="endpoints",
        verbose_name="Routing Instance",
    )
    autonomous_system = models.ForeignKey(
        to=AutonomousSystem,
        blank=True,
        null=True,
        related_name="endpoints",
        on_delete=models.PROTECT,
        verbose_name="Autonomous System",
    )
    peer = models.ForeignKey(to="self", on_delete=models.SET_NULL, blank=True, null=True)
    peering = models.ForeignKey(to=Peering, on_delete=models.CASCADE, related_name="endpoints")
    peer_group = models.ForeignKey(
        to=PeerGroup,
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="endpoints",
        verbose_name="Peer Group",
    )
    source_ip = models.ForeignKey(
        to="ipam.IPAddress",
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="routing_bgp_peer_endpoints",
        verbose_name="Source IP",
    )
    source_interface = models.ForeignKey(
        to="dcim.Interface",
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="routing_bgp_peer_endpoints",
        verbose_name="Source Interface",
    )
    secret = models.ForeignKey(
        to="extras.Secret",
        on_delete=models.PROTECT,
        related_name="routing_bgp_peer_endpoints",
        blank=True,
        null=True,
    )

    class Meta:
        verbose_name = "BGP Peer Endpoint"
        verbose_name_plural = "BGP Peer Endpoints"

    def __str__(self):
        asn, _, _ = self.get_inherited_field(field_name="autonomous_system")
        if self.routing_instance and self.routing_instance.device:
            return f"{self.routing_instance.device} {self.source_ip} ({asn})"
        return f"{self.source_ip} ({asn})"

    def clean(self):
        super().clean()
        asn_value, _, _ = self.get_inherited_field(field_name="autonomous_system")
        if not asn_value:
            raise ValidationError(f"ASN not found at any inheritance level for {self}.")


@extras_features("custom_fields", "relationships")
class AddressFamily(RoutingPrimaryModel, BGPExtraAttributesMixin):
    """BGP address family policy."""

    afi_safi = models.CharField(max_length=20, choices=AFISAFIChoices, verbose_name="AFI/SAFI")
    tags = TagsField(related_name="routing_bgp_address_families")
    routing_instance = models.ForeignKey(
        to=BGPRoutingInstance,
        on_delete=models.CASCADE,
        related_name="address_families",
        verbose_name="Routing Instance",
    )
    import_policy = models.ForeignKey(
        to="nautobot_app_routing.RoutingPolicy",
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name="bgp_import_afs",
        verbose_name="Import Policy",
    )
    export_policy = models.ForeignKey(
        to="nautobot_app_routing.RoutingPolicy",
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name="bgp_export_afs",
        verbose_name="Export Policy",
    )

    class Meta:
        verbose_name = "BGP Address Family"
        verbose_name_plural = "BGP Address Families"
        unique_together = [("routing_instance", "afi_safi")]

    def __str__(self):
        return f"{self.routing_instance} {self.afi_safi}"
