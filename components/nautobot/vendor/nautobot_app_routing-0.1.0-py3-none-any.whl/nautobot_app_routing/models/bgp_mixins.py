# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""BGP mixins vendored from nautobot-app-bgp-models."""

import functools
from collections import OrderedDict

from django.core.serializers.json import DjangoJSONEncoder
from django.db import models
from nautobot.apps.utils import deepmerge


def rgetattr(obj, attr, *args):
    """Recursive getattr helper."""

    def _getattr(obj, attr):
        return getattr(obj, attr, *args)

    return functools.reduce(_getattr, [obj] + attr.split("."))


class InheritanceMixin(models.Model):
    """BGP common inheritance mixin."""

    def get_inherited_field(self, field_name, inheritance_path=None):
        """Return value, inheritance indicator, and inheritance source."""
        field_value = getattr(self, field_name, None)
        if field_value:
            return field_value, False, None

        if inheritance_path is None and field_name in getattr(self, "property_inheritance", {}):
            inheritance_path = self.property_inheritance[field_name]

        for path_element in inheritance_path or []:
            path_with_field = f"{path_element}.{field_name}"
            field_value = rgetattr(self, path_with_field, None)
            if field_value:
                obj = rgetattr(self, ".".join(path_with_field.split(".")[:-1]), None)
                return field_value, True, obj

        return None, False, None

    class Meta:
        abstract = True


class BGPExtraAttributesMixin(models.Model):
    """BGP extra attributes mixin."""

    extra_attributes = models.JSONField(
        encoder=DjangoJSONEncoder,
        blank=True,
        null=True,
        verbose_name="Extra Attributes",
        help_text="Additional BGP attributes",
    )

    @property
    def extra_attributes_inherited(self):
        """Merge inherited and local extra attributes."""
        paths = getattr(self, "extra_attributes_inheritance", [])
        data = OrderedDict()
        for path in paths:
            inherited = rgetattr(self, f"{path}.extra_attributes", None)
            if inherited:
                data = deepmerge(data, inherited)
        if self.extra_attributes:
            data = deepmerge(data, self.extra_attributes)
        return data

    class Meta:
        abstract = True
