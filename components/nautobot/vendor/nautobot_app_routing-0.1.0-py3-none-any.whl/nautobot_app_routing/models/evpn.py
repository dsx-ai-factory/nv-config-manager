# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""EVPN-VPWS service models."""

from django.core.exceptions import ValidationError
from django.db import models
from nautobot.apps.models import extras_features
from nautobot.core.constants import CHARFIELD_MAX_LENGTH
from nautobot.extras.models import StatusField

from nautobot_app_routing.models.base import RoutingPrimaryModel


@extras_features("graphql", "statuses")
class EVPNPWService(RoutingPrimaryModel):
    """EVPN VPWS pseudowire service anchored on its local attachment interface."""

    name = models.CharField(max_length=CHARFIELD_MAX_LENGTH, unique=True)
    local_service_id = models.PositiveIntegerField(verbose_name="Local Service ID")
    remote_service_id = models.PositiveIntegerField(verbose_name="Remote Service ID")
    interface = models.ForeignKey(
        "dcim.Interface",
        on_delete=models.PROTECT,
        related_name="vpws_services",
    )
    remote_pe = models.ForeignKey(
        "dcim.Device",
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="vpws_services_remote",
        verbose_name="Remote PE",
    )
    remote_pe_address = models.GenericIPAddressField(
        blank=True,
        null=True,
        verbose_name="Remote PE Address",
    )
    circuit = models.ForeignKey(
        "circuits.Circuit",
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="vpws_services",
    )
    route_distinguisher = models.CharField(
        max_length=CHARFIELD_MAX_LENGTH,
        verbose_name="Route Distinguisher",
    )
    import_target = models.CharField(max_length=CHARFIELD_MAX_LENGTH, verbose_name="Import Target")
    export_target = models.CharField(max_length=CHARFIELD_MAX_LENGTH, verbose_name="Export Target")
    transport_class = models.ForeignKey(
        "nautobot_app_routing.TransportClass",
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="vpws_services",
        verbose_name="Transport Class",
    )
    mtu = models.PositiveIntegerField(blank=True, null=True, verbose_name="MTU")
    status = StatusField()

    class Meta:
        ordering = ["name"]
        verbose_name = "EVPN VPWS Service"
        verbose_name_plural = "EVPN VPWS Services"

    def __str__(self):
        return self.name

    def clean(self):
        super().clean()
        if not self.remote_pe_id and not self.remote_pe_address:
            raise ValidationError("Set remote_pe or remote_pe_address to identify the far-end PE.")
