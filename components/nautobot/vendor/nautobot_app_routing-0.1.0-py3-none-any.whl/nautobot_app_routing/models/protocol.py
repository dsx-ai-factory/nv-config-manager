# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Protocol intent attached to core Devices and Interfaces."""

from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from nautobot.apps.models import extras_features
from nautobot.core.constants import CHARFIELD_MAX_LENGTH

from nautobot_app_routing.choices import (
    ISISLevelChoices,
    MACsecModeChoices,
    RSVPProtectionChoices,
)
from nautobot_app_routing.models.base import RoutingPrimaryModel


@extras_features("graphql")
class ISISRoutingInstance(RoutingPrimaryModel):
    """Device-level IS-IS process (NET and protocol authentication)."""

    device = models.OneToOneField(
        "dcim.Device",
        on_delete=models.CASCADE,
        related_name="isis_routing_instance",
    )
    net = models.CharField(max_length=64, verbose_name="NET")
    protocol_authentication = models.ForeignKey(
        "extras.Secret",
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name="isis_routing_instances",
        verbose_name="LSP Authentication",
        help_text="Secret for LSP, CSNP, and PSNP authentication",
    )

    class Meta:
        ordering = ["device__name"]
        verbose_name = "IS-IS Routing Instance"
        verbose_name_plural = "IS-IS Routing Instances"

    def __str__(self):
        return f"{self.device} {self.net}"

    def clean(self):
        super().clean()
        if not self.net:
            raise ValidationError({"net": "IS-IS NET is required."})


@extras_features("graphql")
class ISISInterface(RoutingPrimaryModel):
    """IS-IS intent for a core Interface."""

    interface = models.OneToOneField(
        "dcim.Interface",
        on_delete=models.CASCADE,
        related_name="isis",
    )
    metric = models.PositiveIntegerField(default=10)
    level = models.CharField(max_length=3, choices=ISISLevelChoices, default=ISISLevelChoices.LEVEL_2)
    passive = models.BooleanField(default=False)
    hello_authentication = models.ForeignKey(
        "extras.Secret",
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name="isis_interfaces",
        verbose_name="Hello Authentication",
    )

    class Meta:
        ordering = ["interface__device__name", "interface__name"]
        verbose_name = "IS-IS Interface"
        verbose_name_plural = "IS-IS Interfaces"

    def __str__(self):
        return f"IS-IS {self.interface}"


@extras_features("graphql")
class MPLSInterface(RoutingPrimaryModel):
    """MPLS traffic-engineering intent for a core Interface."""

    interface = models.OneToOneField(
        "dcim.Interface",
        on_delete=models.CASCADE,
        related_name="mpls",
    )
    srlg = models.JSONField(default=list, blank=True, verbose_name="SRLGs")
    admin_groups = models.JSONField(default=list, blank=True, verbose_name="Admin Groups")

    class Meta:
        ordering = ["interface__device__name", "interface__name"]
        verbose_name = "MPLS Interface"
        verbose_name_plural = "MPLS Interfaces"

    def __str__(self):
        return f"MPLS {self.interface}"


@extras_features("graphql")
class RSVPInterface(RoutingPrimaryModel):
    """RSVP-TE intent for a core Interface."""

    interface = models.OneToOneField(
        "dcim.Interface",
        on_delete=models.CASCADE,
        related_name="rsvp",
    )
    subscription_percent = models.PositiveSmallIntegerField(
        default=100,
        validators=[MinValueValidator(1), MaxValueValidator(100)],
        verbose_name="Subscription Percent",
    )
    update_threshold_percent = models.PositiveSmallIntegerField(
        default=0,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name="Update Threshold Percent",
    )
    link_protection = models.CharField(
        max_length=30,
        choices=RSVPProtectionChoices,
        default=RSVPProtectionChoices.BYPASS,
        verbose_name="Link Protection",
    )

    class Meta:
        ordering = ["interface__device__name", "interface__name"]
        verbose_name = "RSVP Interface"
        verbose_name_plural = "RSVP Interfaces"

    def __str__(self):
        return f"RSVP {self.interface}"


@extras_features("graphql")
class MACsecAssociation(RoutingPrimaryModel):
    """MACsec connectivity association and keychain policy."""

    name = models.CharField(max_length=CHARFIELD_MAX_LENGTH, unique=True)
    mode = models.CharField(max_length=20, choices=MACsecModeChoices, default=MACsecModeChoices.PRESHARED)
    include_sci = models.BooleanField(default=False, verbose_name="Include SCI")
    secret = models.ForeignKey(
        "extras.Secret",
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name="macsec_associations",
    )
    interfaces = models.ManyToManyField(
        "dcim.Interface",
        related_name="macsec_associations",
        blank=True,
    )

    class Meta:
        ordering = ["name"]
        verbose_name = "MACsec Association"
        verbose_name_plural = "MACsec Associations"

    def __str__(self):
        return self.name
