# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""MPLS LSP and transport models."""

from django.db import models
from nautobot.apps.models import extras_features
from nautobot.core.constants import CHARFIELD_MAX_LENGTH
from nautobot.extras.models import StatusField

from nautobot_app_routing.choices import LSPClassChoices
from nautobot_app_routing.models.base import RoutingPrimaryModel


@extras_features("graphql", "statuses")
class TransportClass(RoutingPrimaryModel):
    """MPLS transport class for LSP coloring."""

    name = models.CharField(max_length=CHARFIELD_MAX_LENGTH, unique=True)
    lsp_class = models.CharField(
        max_length=10,
        choices=LSPClassChoices,
        default=LSPClassChoices.BASE,
        verbose_name="LSP Class",
    )
    color = models.PositiveIntegerField(blank=True, null=True)
    status = StatusField()

    class Meta:
        ordering = ["name"]
        verbose_name = "Transport Class"
        verbose_name_plural = "Transport Classes"

    def __str__(self):
        return self.name


@extras_features("graphql")
class MPLSTemplate(RoutingPrimaryModel):
    """Reusable MPLS LSP template."""

    name = models.CharField(max_length=CHARFIELD_MAX_LENGTH, unique=True)
    description = models.CharField(max_length=CHARFIELD_MAX_LENGTH, blank=True)
    transport_class = models.ForeignKey(
        TransportClass,
        on_delete=models.PROTECT,
        related_name="mpls_templates",
        verbose_name="Transport Class",
    )

    class Meta:
        ordering = ["name"]
        verbose_name = "LSP Template"
        verbose_name_plural = "LSP Templates"

    def __str__(self):
        return self.name


@extras_features("graphql", "statuses")
class LabelSwitchedPath(RoutingPrimaryModel):
    """Device-scoped MPLS LSP."""

    name = models.CharField(max_length=CHARFIELD_MAX_LENGTH)
    device = models.ForeignKey("dcim.Device", on_delete=models.CASCADE, related_name="lsps")
    template = models.ForeignKey(
        MPLSTemplate,
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="lsps",
    )
    to_address = models.GenericIPAddressField(blank=True, null=True, verbose_name="To Address")
    status = StatusField()

    class Meta:
        ordering = ["device__name", "name"]
        unique_together = [("device", "name")]
        verbose_name = "LSP"
        verbose_name_plural = "LSPs"

    def __str__(self):
        return f"{self.device} {self.name}"
