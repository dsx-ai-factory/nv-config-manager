# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Routing policy, prefix-list, and community models."""

from django.db import models
from nautobot.apps.models import extras_features
from nautobot.core.constants import CHARFIELD_MAX_LENGTH

from nautobot_app_routing.choices import (
    AddressFamilyChoices,
    CommunityKindChoices,
    PolicyActionChoices,
    PrefixMatchChoices,
)
from nautobot_app_routing.models.base import RoutingPrimaryModel


@extras_features("graphql")
class CommunityDimension(RoutingPrimaryModel):
    """Hierarchical community ID from render_context continents/metros/sites/types."""

    kind = models.CharField(max_length=20, choices=CommunityKindChoices)
    code = models.CharField(max_length=CHARFIELD_MAX_LENGTH)
    community_id = models.CharField(max_length=32, verbose_name="Community ID")
    parent = models.ForeignKey(
        "self",
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="children",
    )
    location = models.ForeignKey(
        "dcim.Location",
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name="routing_community_dimensions",
    )
    description = models.CharField(max_length=CHARFIELD_MAX_LENGTH, blank=True)

    class Meta:
        ordering = ["kind", "code"]
        unique_together = [("kind", "code")]
        verbose_name = "Community Dimension"
        verbose_name_plural = "Community Dimensions"

    def __str__(self):
        return f"{self.code} ({self.community_id})"


@extras_features("graphql")
class PrefixList(RoutingPrimaryModel):
    """Named prefix list for routing policy."""

    name = models.CharField(max_length=CHARFIELD_MAX_LENGTH, unique=True)
    description = models.CharField(max_length=CHARFIELD_MAX_LENGTH, blank=True)
    address_family = models.CharField(
        max_length=8,
        choices=AddressFamilyChoices,
        default=AddressFamilyChoices.IPV4,
        verbose_name="Address Family",
    )

    class Meta:
        ordering = ["name"]
        verbose_name = "Prefix List"
        verbose_name_plural = "Prefix Lists"

    def __str__(self):
        return self.name


@extras_features("graphql")
class PrefixListEntry(RoutingPrimaryModel):
    """One prefix and match qualifier in a prefix list."""

    prefix_list = models.ForeignKey(
        PrefixList,
        on_delete=models.CASCADE,
        related_name="entries",
        verbose_name="Prefix List",
    )
    prefix = models.CharField(max_length=64)
    match = models.CharField(max_length=16, choices=PrefixMatchChoices, default=PrefixMatchChoices.EXACT)

    class Meta:
        ordering = ["prefix_list__name", "prefix"]
        unique_together = [("prefix_list", "prefix", "match")]
        verbose_name = "Prefix List Entry"
        verbose_name_plural = "Prefix List Entries"

    def __str__(self):
        return f"{self.prefix_list.name} {self.prefix}|{self.match}"


@extras_features("graphql")
class RoutingPolicy(RoutingPrimaryModel):
    """Named routing policy for import/export filters."""

    name = models.CharField(max_length=CHARFIELD_MAX_LENGTH, unique=True)
    description = models.CharField(max_length=CHARFIELD_MAX_LENGTH, blank=True)
    default_action = models.CharField(
        max_length=10,
        choices=PolicyActionChoices,
        default=PolicyActionChoices.REJECT,
        verbose_name="Default Action",
    )

    class Meta:
        ordering = ["name"]
        verbose_name = "Routing Policy"
        verbose_name_plural = "Routing Policies"

    def __str__(self):
        return self.name


@extras_features("graphql")
class RoutingPolicyTerm(RoutingPrimaryModel):
    """Ordered term in a routing policy."""

    policy = models.ForeignKey(RoutingPolicy, on_delete=models.CASCADE, related_name="terms")
    name = models.CharField(max_length=CHARFIELD_MAX_LENGTH)
    sequence = models.PositiveIntegerField(default=10)
    from_policy = models.TextField(blank=True, verbose_name="From Policy")
    then_action = models.CharField(
        max_length=10,
        choices=PolicyActionChoices,
        default=PolicyActionChoices.ACCEPT,
        verbose_name="Then Action",
    )

    class Meta:
        ordering = ["policy__name", "sequence", "name"]
        unique_together = [("policy", "name")]
        verbose_name = "Routing Policy Term"
        verbose_name_plural = "Routing Policy Terms"

    def __str__(self):
        return f"{self.policy.name} {self.name}"
