# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Shared routing model bases."""

from nautobot.apps.models import OrganizationalModel, PrimaryModel


class RoutingPrimaryModel(PrimaryModel):
    """Primary model without Dynamic Group association."""

    is_dynamic_group_associable_model = False

    class Meta:
        abstract = True


class RoutingOrganizationalModel(OrganizationalModel):
    """Organizational model without Dynamic Group association."""

    is_dynamic_group_associable_model = False

    class Meta:
        abstract = True
