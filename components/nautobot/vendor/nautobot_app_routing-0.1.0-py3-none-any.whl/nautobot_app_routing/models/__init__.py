# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Routing plugin models."""

from nautobot_app_routing.models.bgp import (
    AddressFamily,
    AutonomousSystem,
    BGPRoutingInstance,
    PeerEndpoint,
    PeerGroup,
    PeerGroupTemplate,
    Peering,
)
from nautobot_app_routing.models.evpn import EVPNPWService
from nautobot_app_routing.models.mpls import LabelSwitchedPath, MPLSTemplate, TransportClass
from nautobot_app_routing.models.policy import (
    CommunityDimension,
    PrefixList,
    PrefixListEntry,
    RoutingPolicy,
    RoutingPolicyTerm,
)
from nautobot_app_routing.models.protocol import (
    ISISInterface,
    ISISRoutingInstance,
    MACsecAssociation,
    MPLSInterface,
    RSVPInterface,
)

__all__ = [
    "AddressFamily",
    "AutonomousSystem",
    "BGPRoutingInstance",
    "CommunityDimension",
    "EVPNPWService",
    "ISISInterface",
    "ISISRoutingInstance",
    "LabelSwitchedPath",
    "MACsecAssociation",
    "MPLSInterface",
    "MPLSTemplate",
    "PeerEndpoint",
    "PeerGroup",
    "PeerGroupTemplate",
    "Peering",
    "PrefixList",
    "PrefixListEntry",
    "RSVPInterface",
    "RoutingPolicy",
    "RoutingPolicyTerm",
    "TransportClass",
]
