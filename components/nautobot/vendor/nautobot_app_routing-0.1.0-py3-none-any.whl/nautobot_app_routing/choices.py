# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Choice sets for routing plugin demo models."""

from nautobot.apps.choices import ChoiceSet


class InterfaceProfileChoices(ChoiceSet):
    """Backbone profile matrix from the workbook, seeded as dcim.Interface roles."""

    BACKBONE_INTRA_SITE = "backbone_intra_site"
    BACKBONE_LONG_HAUL = "backbone_long_haul"
    ROUTED_INTERNAL = "routed_internal"
    ROUTED_INTERNAL_SUBUNIT = "routed_internal_subunit"
    TRUNK = "trunk"
    SVI = "svi"
    ROUTED_PEER = "routed_peer"
    ROUTED_PEER_SUBUNIT = "routed_peer_subunit"
    BARE_PEER = "bare_peer"
    PSEUDOWIRE = "pseudowire"

    CHOICES = (
        (BACKBONE_INTRA_SITE, "Backbone intra-site"),
        (BACKBONE_LONG_HAUL, "Backbone long haul"),
        (ROUTED_INTERNAL, "Routed to internal device"),
        (ROUTED_INTERNAL_SUBUNIT, "Routed sub-unit to internal device"),
        (TRUNK, "Trunk"),
        (SVI, "SVI"),
        (ROUTED_PEER, "Routed to carrier or peer"),
        (ROUTED_PEER_SUBUNIT, "Routed sub-unit to carrier or peer"),
        (BARE_PEER, "Bare to carrier or peer"),
        (PSEUDOWIRE, "Pseudowire"),
    )


class ISISLevelChoices(ChoiceSet):
    """IS-IS interface level."""

    LEVEL_1 = "1"
    LEVEL_2 = "2"
    LEVEL_1_2 = "1-2"

    CHOICES = (
        (LEVEL_1, "Level 1"),
        (LEVEL_2, "Level 2"),
        (LEVEL_1_2, "Level 1-2"),
    )


class LSPClassChoices(ChoiceSet):
    """MPLS LSP priority class."""

    BASE = "base"
    HIPRI = "hipri"
    LOPRI = "lopri"

    CHOICES = (
        (BASE, "Base"),
        (HIPRI, "High Priority"),
        (LOPRI, "Low Priority"),
    )


class RSVPProtectionChoices(ChoiceSet):
    """RSVP link protection modes."""

    BYPASS = "bypass"
    BYPASS_EXCLUDING_SRLG = "bypass_excluding_srlg"

    CHOICES = (
        (BYPASS, "Bypass"),
        (BYPASS_EXCLUDING_SRLG, "Bypass Excluding SRLG"),
    )


class CommunityKindChoices(ChoiceSet):
    """Community dimension kinds from render_context."""

    CONTINENT = "continent"
    REGION = "region"
    METRO = "metro"
    SITE = "site"
    SCOPE = "scope"
    TYPE = "type"
    CLOUD_PROVIDER = "cloud_provider"

    CHOICES = (
        (CONTINENT, "Continent"),
        (REGION, "Region"),
        (METRO, "Metro"),
        (SITE, "Site"),
        (SCOPE, "Scope"),
        (TYPE, "Type"),
        (CLOUD_PROVIDER, "Cloud Provider"),
    )


class AddressFamilyChoices(ChoiceSet):
    """Prefix-list address family."""

    IPV4 = "ipv4"
    IPV6 = "ipv6"

    CHOICES = (
        (IPV4, "IPv4"),
        (IPV6, "IPv6"),
    )


class PrefixMatchChoices(ChoiceSet):
    """Prefix-list match qualifier."""

    EXACT = "exact"
    ORLONGER = "orlonger"
    UPTO = "upto"

    CHOICES = (
        (EXACT, "exact"),
        (ORLONGER, "orlonger"),
        (UPTO, "upto"),
    )


class PolicyActionChoices(ChoiceSet):
    """Routing policy default and term actions."""

    ACCEPT = "accept"
    REJECT = "reject"

    CHOICES = (
        (ACCEPT, "Accept"),
        (REJECT, "Reject"),
    )


class MACsecModeChoices(ChoiceSet):
    """MACsec connectivity association mode."""

    PRESHARED = "preshared"

    CHOICES = ((PRESHARED, "Preshared"),)


class AFISAFIChoices(ChoiceSet):
    """BGP AFI/SAFI identifiers (vendored subset)."""

    IPV4_UNICAST = "ipv4_unicast"
    IPV6_UNICAST = "ipv6_unicast"
    L2VPN_EVPN = "l2vpn_evpn"

    CHOICES = (
        (IPV4_UNICAST, "IPv4 Unicast"),
        (IPV6_UNICAST, "IPv6 Unicast"),
        (L2VPN_EVPN, "L2VPN EVPN"),
    )
